#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
sys.path.insert(0, str(SRC))

from dikwp_antithesis.conformance import run_conformance  # noqa: E402
from dikwp_antithesis.ledger import HashLedger  # noqa: E402
from dikwp_antithesis.util import sha256_json, write_json  # noqa: E402


def run() -> dict:
    checks: list[dict] = []

    def check(name: str, function) -> None:
        try:
            detail = function()
            checks.append({'name': name, 'status': 'PASS', 'detail': detail})
        except Exception as exc:
            checks.append({'name': name, 'status': 'FAIL', 'detail': f'{type(exc).__name__}: {exc}'})

    check('unit_tests', test_unit_tests)
    check('constitutional_conformance', test_conformance)
    check('demo_report_invariants', test_demo_report)
    check('demo_ledger_integrity', test_ledger)
    check('all_json_files_parse', test_json_parse)
    check('schemas_are_declared', test_schemas)
    check('dashboard_is_self_contained', test_dashboard)
    check('phi0_does_not_exceed_e3', test_phi0_boundary)
    check('wheel_install_and_conformance', test_wheel_install)
    passed = sum(1 for item in checks if item['status'] == 'PASS')
    failed = len(checks) - passed
    report = {
        'system': 'DIKWP-MESH5 ΦX / ANTITHESIS',
        'version': '1.0.0',
        'status': 'PASS' if failed == 0 else 'FAIL',
        'passed': passed,
        'failed': failed,
        'checks': checks,
        'network_validation': {
            'status': 'SKIPPED',
            'reason': 'The isolated build environment had no DNS access. GitHub importer is covered by identifier and offline scanner tests but requires external execution for a live API check.'
        }
    }
    report['report_hash'] = sha256_json(report)
    return report


def test_unit_tests() -> str:
    result = subprocess.run(
        [sys.executable, '-m', 'pytest', '-q'],
        cwd=ROOT,
        env={**dict(__import__('os').environ), 'PYTHONPATH': str(SRC)},
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(result.stdout + result.stderr)
    return result.stdout.strip()


def test_conformance() -> str:
    report = run_conformance()
    assert report['status'] == 'PASS'
    assert report['failed'] == 0
    return f"{report['passed']} passed; hash={report['report_hash']}"


def load_demo() -> dict:
    return json.loads((ROOT / 'outputs/demo/portfolio_report.json').read_text(encoding='utf-8'))


def test_demo_report() -> dict:
    report = load_demo()
    assert report['summary']['decision_counts']['PROMOTE'] == 0
    assert report['summary']['repository_count'] == 12
    assert report['minimum_decisive_set'][0]['experiment_type'] == 'contradiction-bridge'
    names = {repo['id']: repo['name'] for repo in report['repositories']}
    claims = {claim['id']: claim for claim in report['claims']}
    targets = [names[claims[cid]['repo_id']] for cid in report['minimum_decisive_set'][0]['target_claim_ids']]
    assert any('Φ0' in name for name in targets)
    assert any('RUNTIME' in name.upper() for name in targets)
    return {'summary': report['summary'], 'first_experiment_targets': targets}


def test_ledger() -> dict:
    verification = HashLedger.load(ROOT / 'outputs/demo/ledger.jsonl').verify()
    assert verification['status'] == 'PASS'
    return verification


def test_json_parse() -> int:
    count = 0
    for path in ROOT.rglob('*.json'):
        json.loads(path.read_text(encoding='utf-8'))
        count += 1
    return count


def test_schemas() -> int:
    schemas = list((ROOT / 'schemas').glob('*.schema.json'))
    assert len(schemas) >= 8
    for path in schemas:
        value = json.loads(path.read_text(encoding='utf-8'))
        assert value.get('$schema') == 'https://json-schema.org/draft/2020-12/schema'
    return len(schemas)


def test_dashboard() -> dict:
    text = (ROOT / 'outputs/demo/dashboard.html').read_text(encoding='utf-8')
    assert 'ANTITHESIS' in text
    assert '__ANTITHESIS_DATA__' not in text
    assert 'https://cdn' not in text and '<script src=' not in text
    return {'bytes': len(text.encode('utf-8')), 'external_scripts': 0}


def test_phi0_boundary() -> int:
    report = load_demo()
    phi0_repo_ids = {repo['id'] for repo in report['repositories'] if 'Φ0' in repo['name']}
    phi0_claim_ids = {claim['id'] for claim in report['claims'] if claim['repo_id'] in phi0_repo_ids}
    levels = [item['level'] for item in report['evidence'] if item['claim_id'] in phi0_claim_ids]
    assert levels and max(levels) <= 3
    return max(levels)


def test_wheel_install() -> str:
    wheels = sorted((ROOT / 'dist').glob('dikwp_antithesis-*.whl'))
    assert wheels, 'No wheel found in dist/'
    with tempfile.TemporaryDirectory() as directory:
        install = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '--no-deps', '--target', directory, str(wheels[-1])],
            capture_output=True,
            text=True,
            check=False,
        )
        if install.returncode != 0:
            raise AssertionError(install.stdout + install.stderr)
        execution = subprocess.run(
            [sys.executable, '-m', 'dikwp_antithesis', 'conformance'],
            env={**dict(__import__('os').environ), 'PYTHONPATH': directory},
            capture_output=True,
            text=True,
            check=False,
        )
        if execution.returncode != 0:
            raise AssertionError(execution.stdout + execution.stderr)
        payload = json.loads(execution.stdout)
        assert payload['status'] == 'PASS'
        return f"{wheels[-1].name}: {payload['passed']} conformance checks passed"


if __name__ == '__main__':
    result = run()
    write_json(ROOT / 'VALIDATION_REPORT.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)
