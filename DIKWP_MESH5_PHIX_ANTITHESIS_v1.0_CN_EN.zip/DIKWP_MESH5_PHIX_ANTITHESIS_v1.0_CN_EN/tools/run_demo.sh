#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/outputs/demo}"
PHI0="${2:-}"
ARGS=(demo --out "$OUT" --budget 60 --max-experiments 12 --as-of 2026-07-22T12:00:00Z)
if [[ -n "$PHI0" ]]; then ARGS+=(--phi0 "$PHI0"); fi
PYTHONPATH="$ROOT/src" python -m dikwp_antithesis "${ARGS[@]}"
