#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from dikwp_antithesis.ledger import HashLedger

parser = argparse.ArgumentParser()
parser.add_argument('ledger')
args = parser.parse_args()
print(json.dumps(HashLedger.load(args.ledger).verify(), indent=2, ensure_ascii=False))
