# Governance

## Maintainer obligations

Maintainers must preserve:

- claim-level evidence states;
- adverse receipts and residuals;
- versioned policy thresholds;
- reversible release decisions;
- a clear distinction between author-side and independent evidence.

## Policy changes

Changes to promotion, evidence or independence thresholds require:

1. a version increment;
2. a rationale and affected-decision analysis;
3. replay of the conformance suite;
4. regeneration of demo outputs;
5. a new ledger root;
6. no retroactive deletion of prior decisions.

## Conflict of interest

A maintainer may submit evidence for their own claim, but the evidence remains author-side unless a genuinely independent producer controls the protocol execution and result publication.

## Decision appeals

An appeal must target a concrete claim, receipt, relation or policy rule. Appeals are resolved by adding new evidence or correcting a traceable error, never by silently editing history.
