# Contributing

## Required workflow

1. Open or identify a claim ID.
2. State the expected falsifier before implementation.
3. Add or update tests.
4. Run `python -m pytest -q`.
5. Run `dikwp-antithesis conformance`.
6. Regenerate demo outputs if policy or scoring changes.
7. Preserve adverse results.

## Code constraints

- Python standard library is preferred for the core runtime.
- No hidden network calls.
- No arbitrary shell execution.
- Deterministic baselines must be labeled as baselines.
- New decision rules need explicit reason codes.
- New evidence levels are not accepted without a migration specification.

## Pull-request evidence

A passing test suite is E3 author-side evidence. It is not independent replication of the scientific or governance claims in the repository.
