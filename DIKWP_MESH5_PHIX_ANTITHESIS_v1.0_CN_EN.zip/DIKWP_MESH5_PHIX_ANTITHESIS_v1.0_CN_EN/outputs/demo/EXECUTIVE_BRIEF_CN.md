# ANTITHESIS 执行摘要

生成时间：2026-07-22T12:00:00Z

## 宪法性结论

本系统不把“仓库存在、README 完整、自测通过”视为科学成立。证据状态逐主张计算；同一团队产生的多份成功记录会被折扣；没有独立复现就不能进入 PROMOTE。

- 仓库：12；主张：14；证据记录：19。
- 决策分布：HOLD=4, PILOT=1, PROMOTE=0, RETIRE=0, REVIEW=7。
- 证伪债务指数：0.815。
- 未解决冲突：1；疑似重复簇：1。
- 当前没有证据自动升级：PROMOTE=0。

## 最小决定性实验

### 1. DIKWP-MESH-RUNTIME-Commons-v1.0 ↔ DIKWP-Mesh 5.0 Φ0

主张：The runtime exposes all 25 ordered DIKWP transformations with observer, context, time, scale, purpose and provenance indexes while preserving conflicts and residuals.；The machine core aligns interventions by downstream causal equivalence without human labels; DIKWP and language are optional lossy witness projections.

实验类型：contradiction-bridge。

优先分：88.168；预计信息增益：0.598381；成本单位：7.64。

干预：Freeze one perturbation family and two heterogeneous open-weight models. Compare three arms: (A) Φ0 causal-equivalence transfer, (B) Runtime Commons semantic-contract transfer, and (C) a layered Φ0-core → lossy DIKWP audit shadow → Runtime contract. Preregister the interface and prohibit post-result redefinition.

测量：Held-out transfer accuracy, cycle error, projection loss, semantic leakage into the Φ0 core, residual retention, 25-transform conformance, rollback error, and cross-team reproducibility.

失败阈值：Reject the unified layered architecture if the semantic witness changes Φ0 equivalence classes, if Φ0 cannot expose a stable auditable shadow, if residuals disappear, or if either standalone arm outperforms the layered arm beyond the preregistered tolerance.

解锁决策：Resolve joint REVIEW for repo-dikwp-mesh5-phi0 and REPO-b157c0585a36b6; retain both only if a scoped layer distinction is experimentally observable and round-trip safe.

### 2. DIKWP-ProofLedger-OS

主张：ProofLedger can decompose AI outputs into claims, evidence links, conflict signals, risk boundaries and reliability states that remain auditable and correctable.

实验类型：claim-kill-test。

优先分：72.998；预计信息增益：0.711579；成本单位：4.19。

干预：Execute valid, boundary, malformed, tampered, and rollback cases through the public contract in a sandbox.

测量：Deterministic conformance suite plus interoperability, corruption, rollback, and performance tests against a named contract.

失败阈值：a required conformance invariant fails, an accepted artifact cannot round-trip, or tampering is not detected.

解锁决策：Convert a traceable assertion into an executable E2/E3 result.

### 3. DIKWP-MESH-TRUSTFABRIC-Commons-OS-v1.0.0

主张：TRUSTFABRIC can preserve observer, context, plural purpose, authorization, provenance, human control, sovereignty and incident-recovery constraints across agent exchanges.

实验类型：claim-kill-test。

优先分：75.867；预计信息增益：0.711579；成本单位：4.43。

干预：Execute valid, boundary, malformed, tampered, and rollback cases through the public contract in a sandbox.

测量：Deterministic conformance suite plus interoperability, corruption, rollback, and performance tests against a named contract.

失败阈值：a required conformance invariant fails, an accepted artifact cannot round-trip, or tampering is not detected.

解锁决策：Convert a traceable assertion into an executable E2/E3 result.

### 4. DIKWP-MESH5-PHIX-ANTITHESIS

主张：ANTITHESIS detects mutation of a sealed decision or evidence payload through its append-only hash-chain and Merkle verification.

实验类型：claim-kill-test。

优先分：66.888；预计信息增益：0.772808；成本单位：4.29。

干预：Execute valid, boundary, malformed, tampered, and rollback cases through the public contract in a sandbox.

测量：Deterministic conformance suite plus interoperability, corruption, rollback, and performance tests against a named contract.

失败阈值：a required conformance invariant fails, an accepted artifact cannot round-trip, or tampering is not detected.

解锁决策：Move PILOT toward PROMOTE only through independent replication.

### 5. DIKWP-CREDENCE-

主张：CREDENCE can assign evidence and replication states to individual claims rather than laundering credibility across an entire repository.

实验类型：claim-kill-test。

优先分：76.411；预计信息增益：0.711579；成本单位：6.22。

干预：Replay matched decisions with controlled changes to authority, evidence, context, and appeal state.

测量：Traceable decision replay: authorization coverage, appeal success, reversibility, policy consistency, and unlogged action rate.

失败阈值：any material action lacks authority/evidence/appeal provenance, or rollback cannot restore the sealed pre-action state.

解锁决策：Convert a traceable assertion into an executable E2/E3 result.

### 6. DIKWP-MESH-RUNTIME-Commons-v1.0

主张：The runtime exposes all 25 ordered DIKWP transformations with observer, context, time, scale, purpose and provenance indexes while preserving conflicts and residuals.

实验类型：claim-kill-test。

优先分：86.367；预计信息增益：0.711579；成本单位：4.19。

干预：Execute valid, boundary, malformed, tampered, and rollback cases through the public contract in a sandbox.

测量：Deterministic conformance suite plus interoperability, corruption, rollback, and performance tests against a named contract.

失败阈值：a required conformance invariant fails, an accepted artifact cannot round-trip, or tampering is not detected.

解锁决策：Convert a traceable assertion into an executable E2/E3 result.

### 7. DIKWP-EIR-Mesh-v1.0

主张：The EIR-Mesh operating layer can replace unlimited repository expansion with a Repo Atlas, flagship funnel, release gate, resource router and evidence loop.

实验类型：claim-kill-test。

优先分：66.649；预计信息增益：0.711579；成本单位：5.86。

干预：Replay matched decisions with controlled changes to authority, evidence, context, and appeal state.

测量：Traceable decision replay: authorization coverage, appeal success, reversibility, policy consistency, and unlogged action rate.

失败阈值：any material action lacks authority/evidence/appeal provenance, or rollback cannot restore the sealed pre-action state.

解锁决策：Convert a traceable assertion into an executable E2/E3 result.

### 8. DIKWP-MESH5-PHIX-ANTITHESIS

主张：ANTITHESIS ranks a budget-bounded minimum decisive experiment set using uncertainty, importance, centrality, falsification power, independence gap, cost, risk and reversibility.

实验类型：claim-kill-test。

优先分：65.526；预计信息增益：0.818105；成本单位：5.06。

干预：Run the claimed capability on preregistered in-scope and boundary cases, with a frozen baseline and evaluator.

测量：Preregistered task suite with held-out cases, named baseline, uncertainty intervals, failure taxonomy, and adverse-case retention.

失败阈值：the lower confidence bound does not beat the baseline by the declared margin, or a critical scoped failure remains unrecoverable.

解锁决策：Move PILOT toward PROMOTE only through independent replication.

## 不可越过的边界

1. 自测通过仍是内部证据；独立团队失败必须与成功同等公开。
2. 任何主张若没有失败阈值、停止条件和回滚路径，发布状态只能是 HOLD。
3. 仓库级“整体可信”被禁止；不同主张可同时处于 SUPPORTED、CONTESTED 和 FALSIFIED。
4. 所有晋级自动到期，必须用新证据续期。

账本 Merkle 根：`cbf04a2ac12562476dd92f787bdebaadb106839d51344762bdd3ed77ace82d2d`
