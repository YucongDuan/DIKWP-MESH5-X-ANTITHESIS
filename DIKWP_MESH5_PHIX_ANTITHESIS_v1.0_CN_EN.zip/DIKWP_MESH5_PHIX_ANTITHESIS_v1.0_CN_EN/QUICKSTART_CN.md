# 快速启动（中文）

## 1. 安装

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

Windows PowerShell：

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -e .
```

## 2. 先运行自证伪一致性检查

```bash
dikwp-antithesis conformance --out outputs/conformance.json
```

预期：`12 passed / 0 failed`。失败时不要继续发布，应保留失败报告并修复。

## 3. 运行内置研究演示

不导入 Φ0：

```bash
dikwp-antithesis demo --out outputs/demo
```

导入 Φ0 回执：

```bash
dikwp-antithesis demo \
  --out outputs/demo \
  --phi0 /path/to/phi0/outputs/research_run \
  --budget 60
```

## 4. 查看结果

浏览器打开：

```text
outputs/demo/dashboard.html
```

机器可读结果：

```text
outputs/demo/portfolio_report.json
```

## 5. 验证账本

```bash
dikwp-antithesis verify-ledger --input outputs/demo/ledger.jsonl
```

预期：`status = PASS`，并返回 Merkle 根。

## 6. 编译自己的仓库生态

复制并编辑：

```text
examples/portfolio_minimal.json
```

执行：

```bash
dikwp-antithesis compile \
  --input examples/portfolio_minimal.json \
  --out outputs/my_portfolio \
  --policy config/default_constitution.json
```

## 7. 证据录入的最低要求

每条主张至少声明：

- scope；
- authority；
- purpose；
- kill test；
- rollback；
- evidence source 与 producer；
- PASS、CHALLENGE、FALSIFY 或 INCONCLUSIVE。

没有这些字段时，系统应 HOLD，而不是猜测。
