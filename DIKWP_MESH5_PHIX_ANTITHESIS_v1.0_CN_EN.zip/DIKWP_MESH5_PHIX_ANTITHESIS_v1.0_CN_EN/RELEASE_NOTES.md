# Release notes

## v1.0.0 — 2026-07-22

Initial delivery of DIKWP-MESH5 ΦX / ANTITHESIS.

### Included

- deterministic bilingual claim compiler;
- E0—E7 evidence engine with source-independence discount;
- support/contradiction/duplicate/dependency graph;
- generated falsification contracts;
- contradiction-bridge experiment synthesis;
- budget-bounded minimum decisive experiment selection;
- reversible PROMOTE/PILOT/REVIEW/HOLD/RETIRE constitution;
- hash-chain ledger, Merkle root and optional HMAC seal;
- conservative DIKWP-MESH5 Φ0 adapter;
- read-only GitHub and offline local repository scanners;
- offline single-file dashboard;
- 27 unit tests and 12 constitutional conformance checks;
- representative YucongDuan ecosystem research report;
- 90-day execution plan and Φ0 ↔ Runtime bridge protocol.

### Known limitations

- lexical relation inference is a transparent baseline, not general semantic understanding;
- GitHub live network import was not exercised in the isolated build environment because DNS access was unavailable;
- no public-key transparency service or multi-organization identity layer is included;
- the provided Φ0 evidence is synthetic/internal and remains E3;
- no repository in the representative demo reaches PROMOTE.
