from dikwp_antithesis.graph import ClaimGraph
from dikwp_antithesis.models import Claim, ClaimRelation, RelationKind


def c(cid, repo, text):
    return Claim(id=cid, repo_id=repo, text=text, claim_type='infrastructure')


def test_infers_duplicate_cluster():
    graph = ClaimGraph([
        c('a', 'r1', 'The runtime detects ledger tampering under the declared scope.'),
        c('b', 'r2', 'The runtime detects ledger tampering within the declared scope.'),
    ])
    graph.infer_relations(duplicate_threshold=0.5)
    assert graph.duplicate_clusters(confidence=0.5) == [['a', 'b']]


def test_infers_negated_contradiction():
    graph = ClaimGraph([
        c('a', 'r1', 'The system allows autonomous external execution under this contract.'),
        c('b', 'r2', 'The system does not allow autonomous external execution under this contract.'),
    ])
    graph.infer_relations(contradiction_threshold=0.35)
    assert graph.unresolved_contradictions(confidence=0.4)


def test_detects_dependency_cycle():
    claims = [c('a', 'r1', 'A'), c('b', 'r2', 'B'), c('c', 'r3', 'C')]
    relations = [
        ClaimRelation('a', 'b', RelationKind.DEPENDS_ON),
        ClaimRelation('b', 'c', RelationKind.DEPENDS_ON),
        ClaimRelation('c', 'a', RelationKind.DEPENDS_ON),
    ]
    assert ClaimGraph(claims, relations).dependency_cycles()


def test_centrality_is_normalized():
    claims = [c('a', 'r1', 'A'), c('b', 'r2', 'B')]
    graph = ClaimGraph(claims, [ClaimRelation('a', 'b', RelationKind.SUPPORTS)])
    scores = graph.centrality()
    assert max(scores.values()) == 1.0
