from dikwp_antithesis.ledger import HashLedger


def test_hash_chain_and_merkle_verify():
    ledger = HashLedger()
    ledger.append('A', {'x': 1}, timestamp='2026-01-01T00:00:00Z')
    ledger.append('B', {'x': 2}, timestamp='2026-01-01T00:00:01Z')
    report = ledger.verify()
    assert report['status'] == 'PASS'
    assert report['merkle_root'] != HashLedger.GENESIS


def test_tampering_is_detected():
    ledger = HashLedger()
    ledger.append('A', {'x': 1}, timestamp='2026-01-01T00:00:00Z')
    ledger.records[0]['payload']['x'] = 2
    assert ledger.verify()['status'] == 'FAIL'


def test_hmac_seal_verifies():
    ledger = HashLedger()
    ledger.append('A', {'x': 1}, timestamp='2026-01-01T00:00:00Z')
    seal = ledger.seal(b'secret')
    assert HashLedger.verify_seal(seal, b'secret')
    assert not HashLedger.verify_seal(seal, b'wrong')
