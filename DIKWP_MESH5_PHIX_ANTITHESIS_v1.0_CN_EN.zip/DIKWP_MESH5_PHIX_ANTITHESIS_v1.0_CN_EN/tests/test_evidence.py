from dikwp_antithesis.evidence import EvidenceEngine
from dikwp_antithesis.models import Claim, EvidenceItem, EvidenceLevel, EvidenceResult


def claim():
    return Claim(id='c', repo_id='r', text='Claim', kill_test='kill', rollback='rollback')


def evidence(eid, level, result='support', producer='same', independent=False):
    return EvidenceItem(
        id=eid,
        claim_id='c',
        level=level,
        result=result,
        source=eid,
        producer=producer,
        reproducible=True,
        metadata={'independent': independent},
    )


def test_e1_traceability_does_not_create_supported_status():
    assessment = EvidenceEngine().assess(claim(), [evidence('e1', 1)])
    assert assessment.status.value == 'UNTESTED'
    assert assessment.evidence_level == EvidenceLevel.E1_TRACEABLE


def test_same_producer_is_discounted():
    assessment = EvidenceEngine().assess(claim(), [evidence(f'e{i}', 3) for i in range(6)])
    assert assessment.independence_score < 0.5
    assert assessment.evidence_level == EvidenceLevel.E3_INTERNAL_REPLICATION


def test_independent_high_level_receipts_support_claim():
    items = [
        evidence('e5', 5, producer='lab-b', independent=True),
        evidence('e6', 6, producer='lab-c', independent=True),
    ]
    assessment = EvidenceEngine().assess(claim(), items)
    assert assessment.status.value == 'SUPPORTED'
    assert assessment.independence_score >= 0.9
    assert assessment.credence > 0.8


def test_executable_falsifier_marks_claim_falsified():
    assessment = EvidenceEngine().assess(claim(), [evidence('e3', 3, result='falsify')])
    assert assessment.status.value == 'FALSIFIED'
