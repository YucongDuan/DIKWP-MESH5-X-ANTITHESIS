import json

from dikwp_antithesis.phi0_adapter import Phi0Adapter


def write(path, value):
    path.write_text(json.dumps(value), encoding='utf-8')


def test_phi0_internal_success_remains_e3(tmp_path):
    write(tmp_path / 'summary.json', {'system': 'DIKWP-Mesh 5.0 Φ0', 'core_claim': 'The core aligns interventions.', 'experiments': {'experiments': 1, 'passed': 1, 'failed': 0}})
    write(tmp_path / 'experiments.json', {'aggregate': {'experiments': 1, 'passed': 1, 'failed': 0, 'receipts_hash': 'abc'}})
    write(tmp_path / 'conformance.json', {'passed': 2, 'failed': 0, 'report_hash': 'def'})
    portfolio = Phi0Adapter().import_directory(tmp_path)
    assert max(int(item.level) for item in portfolio.evidence) == 3
    assert all(not item.metadata.get('independent') for item in portfolio.evidence)
    assert portfolio.claims[0].scope == 'synthetic-reference'
