from dikwp_antithesis.claim_compiler import ClaimCompiler
from dikwp_antithesis.models import Claim


def test_extracts_bilingual_claims():
    markdown = '''
# Core
- The runtime implements deterministic conformance tests under a closed-world boundary.
- 系统能够在离线原型中检测篡改，并保留失败记录。
'''
    claims = ClaimCompiler().extract_markdown(markdown, 'repo-x', authority='team', purpose='test')
    assert len(claims) == 2
    assert {claim.repo_id for claim in claims} == {'repo-x'}


def test_compiles_kill_test_and_rollback():
    claim = Claim(id='c', repo_id='r', text='The runtime detects tampering.', authority='a', purpose='p')
    compiled, contract = ClaimCompiler().compile_contract(claim)
    assert compiled.kill_test
    assert compiled.rollback
    assert contract.failure_threshold
    assert contract.metadata['pre_registration_required'] is True


def test_overclaim_risk_rises_for_absolute_unmeasured_language():
    compiler = ClaimCompiler()
    risky = compiler.score_overclaim_risk('This system universally guarantees perfect safety.')
    bounded = compiler.score_overclaim_risk('This offline prototype reports test error under a named boundary.')
    assert risky > bounded


def test_evidence_tax_flags_missing_governance_fields():
    claim = Claim(id='c', repo_id='r', text='The system provides a result.', scope='', authority='', purpose='')
    violations = ClaimCompiler().evidence_tax(claim)
    assert 'MISSING_KILL_TEST' in violations
    assert 'MISSING_ROLLBACK' in violations
    assert 'MISSING_SCOPE' in violations
