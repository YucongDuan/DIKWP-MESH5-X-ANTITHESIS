import pytest

from dikwp_antithesis.github import GitHubClient, LocalRepositoryScanner


def test_github_identifier_validation():
    GitHubClient._validate_identifier('YucongDuan', 'owner')
    with pytest.raises(ValueError):
        GitHubClient._validate_identifier('../bad', 'owner')


def test_local_scanner_marks_readme_as_e1(tmp_path):
    repo = tmp_path / 'repo'
    repo.mkdir()
    (repo / 'README.md').write_text('# X\nThe runtime implements a deterministic test.', encoding='utf-8')
    portfolio = LocalRepositoryScanner().scan([repo])
    assert len(portfolio.repositories) == 1
    assert len(portfolio.claims) == 1
    assert int(portfolio.evidence[0].level) == 1
