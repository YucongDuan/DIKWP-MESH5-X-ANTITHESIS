from dikwp_antithesis.claim_compiler import ClaimCompiler
from dikwp_antithesis.evidence import EvidenceEngine
from dikwp_antithesis.graph import ClaimGraph
from dikwp_antithesis.models import Claim, ClaimRelation, EvidenceItem, RelationKind
from dikwp_antithesis.planner import ExperimentPlanner


def make(cid, repo, text, risk=0.5):
    return Claim(id=cid, repo_id=repo, text=text, importance=0.9, risk=risk, authority='a', purpose='p')


def test_contradiction_generates_joint_bridge_experiment():
    claims, contracts = ClaimCompiler().compile_many([
        make('a', 'r1', 'The core uses semantic coordinates.'),
        make('b', 'r2', 'The core does not use semantic coordinates.'),
    ])
    evidence = [EvidenceItem('e1', 'a', 1, 'support', 'x', 'a'), EvidenceItem('e2', 'b', 1, 'support', 'y', 'b')]
    assessments = EvidenceEngine().assess_all(claims, evidence)
    graph = ClaimGraph(claims, [ClaimRelation('a', 'b', RelationKind.CONTRADICTS, 0.8)])
    plans = ExperimentPlanner().plan(claims, contracts, assessments, graph)
    bridges = [plan for plan in plans if plan.experiment_type == 'contradiction-bridge']
    assert len(bridges) == 1
    assert set(bridges[0].target_claim_ids) == {'a', 'b'}
    assert bridges[0].failure_threshold


def test_minimum_set_respects_budget_and_re_ranks():
    claims, contracts = ClaimCompiler().compile_many([
        make('a', 'r1', 'The runtime detects tampering.'),
        make('b', 'r2', 'The runtime detects corruption.'),
    ])
    assessments = EvidenceEngine().assess_all(claims, [])
    graph = ClaimGraph(claims)
    planner = ExperimentPlanner()
    plans = planner.plan(claims, contracts, assessments, graph)
    budget = max(contract.estimated_cost for contract in contracts)
    selected = planner.minimum_decisive_set(plans, graph, budget=budget)
    assert sum(plan.estimated_cost for plan in selected) <= budget
    assert [plan.rank for plan in selected] == list(range(1, len(selected) + 1))
