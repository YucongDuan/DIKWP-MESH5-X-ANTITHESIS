from datetime import datetime, timezone

from dikwp_antithesis.dashboard import DashboardGenerator
from dikwp_antithesis.demo_data import self_portfolio
from dikwp_antithesis.portfolio import PortfolioCompiler


def test_self_application_never_promotes_on_internal_tests(tmp_path):
    compiler = PortfolioCompiler()
    report = compiler.compile(self_portfolio(), as_of=datetime(2026, 7, 22, tzinfo=timezone.utc))
    assert report['summary']['decision_counts']['PROMOTE'] == 0
    assert report['decisions'][0]['state'] == 'PILOT'
    assert report['ledger_verification']['status'] == 'PASS'
    compiler.write_outputs(report, tmp_path)
    dashboard = DashboardGenerator().generate(report, tmp_path / 'dashboard.html')
    assert 'ANTITHESIS' in dashboard.read_text(encoding='utf-8')


def test_conformance_suite_passes():
    from dikwp_antithesis.conformance import run_conformance
    report = run_conformance()
    assert report['status'] == 'PASS'
    assert report['failed'] == 0
