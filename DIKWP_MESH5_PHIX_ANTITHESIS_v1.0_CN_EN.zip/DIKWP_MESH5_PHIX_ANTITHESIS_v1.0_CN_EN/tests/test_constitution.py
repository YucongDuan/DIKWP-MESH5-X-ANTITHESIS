from datetime import datetime, timezone

from dikwp_antithesis.constitution import ReleaseConstitution
from dikwp_antithesis.evidence import EvidenceEngine
from dikwp_antithesis.graph import ClaimGraph
from dikwp_antithesis.models import Claim, DecisionState, EvidenceItem, Repository


NOW = datetime(2026, 7, 22, tzinfo=timezone.utc)


def make_claim(**kwargs):
    data = dict(
        id='c', repo_id='r', text='The runtime detects tampering.', importance=0.9, risk=0.5,
        kill_test='Fail when tampering is missed.', rollback='Restore sealed state.',
        authority='maintainers', purpose='integrity',
    )
    data.update(kwargs)
    return Claim(**data)


def ev(eid, level, result='support', producer='team-a', independent=False):
    return EvidenceItem(id=eid, claim_id='c', level=level, result=result, source=eid, producer=producer, reproducible=True, metadata={'independent': independent})


def decide(repo, claim, evidence):
    assessment = EvidenceEngine().assess(claim, evidence)
    return ReleaseConstitution().evaluate_repository(repo, [claim], {'c': assessment}, ClaimGraph([claim]), as_of=NOW)


def test_missing_rollback_is_hold():
    decision = decide(Repository('r', 'x'), make_claim(rollback=''), [ev('e3', 3), ev('e2', 2)])
    assert decision.state == DecisionState.HOLD


def test_high_risk_e1_is_hold():
    decision = decide(Repository('r', 'x', risk_level=0.9), make_claim(risk=0.9), [ev('e1', 1)])
    assert decision.state == DecisionState.HOLD


def test_internal_e3_is_pilot_not_promote():
    decision = decide(Repository('r', 'x'), make_claim(), [ev('e3', 3), ev('e2', 2)])
    assert decision.state == DecisionState.PILOT


def test_independent_e5_e6_can_promote():
    evidence = [ev('e5', 5, producer='lab-b', independent=True), ev('e6', 6, producer='lab-c', independent=True)]
    decision = decide(Repository('r', 'x'), make_claim(), evidence)
    assert decision.state == DecisionState.PROMOTE


def test_falsified_core_claim_retires():
    decision = decide(Repository('r', 'x'), make_claim(), [ev('bad', 3, result='falsify')])
    assert decision.state == DecisionState.RETIRE
