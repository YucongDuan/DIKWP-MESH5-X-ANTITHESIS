# Security policy

## Supported version

Version 1.0.x is the current reference line.

## Report a vulnerability

A report should include:

- affected command/module;
- minimal reproduction;
- whether the flaw can create a false PROMOTE, hide adverse evidence, bypass HOLD, or corrupt ledger verification;
- affected claim, receipt or record IDs;
- expected safe behavior.

Do not delete or rewrite the original adverse record after a fix. Publish a new version, migration note and a new ledger receipt.

## Critical classes

The following are release-blocking:

- a tampered ledger verifies as PASS;
- E1 or same-producer E3 evidence is upgraded to independent E5;
- a missing rollback does not force HOLD;
- a falsified core claim can still PROMOTE;
- third-party repository code executes during read-only ingestion;
- result-after-threshold modification is not versioned.

## Network boundary

The GitHub importer performs read-only HTTPS requests. It does not clone, install or execute repository code. Network failures must fail closed and produce no fabricated repository data.
