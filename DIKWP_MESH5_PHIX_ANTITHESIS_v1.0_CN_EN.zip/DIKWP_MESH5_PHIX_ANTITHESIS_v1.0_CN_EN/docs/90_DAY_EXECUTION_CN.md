# ANTITHESIS 90 天执行路线图

目标不是再发布 30 个仓库，而是在 90 天内把生态最关键的主张推到可被外部团队复现或推翻的状态。

## 第 0—15 天：冻结主张与证据基线

### 交付

- 对全部公开仓库生成只读 Repo Atlas；
- 每个旗舰候选最多保留 3 条核心主张；
- 对核心主张生成 kill contract；
- 建立 producer independence 图；
- 为重复仓库生成合并/差异化清单；
- 发布第一版失败与 residual 索引。

### 门禁

- 没有 kill/rollback 的仓库不得进入旗舰候选；
- README 主张统一标记 E1；
- 作者侧测试统一不高于 E3。

## 第 16—35 天：完成 Φ0 ↔ Runtime 桥接实验实现

### 三实验臂

1. Φ0-only；
2. Runtime-only；
3. Φ0 core → DIKWP shadow → Runtime。

### 必须冻结

- 两个异构开放权重模型；
- 扰动族；
- 留出任务；
- 文本与 embedding 基线；
- projection-loss 与 residual-retention 指标；
- kill threshold；
- seed 列表；
- 失败报告模板。

### 安全边界

- 只在离线、无外部执行权限环境中运行；
- 不实现持久化、自复制、逃逸或自主部署；
- 所有输出可回滚并进入账本。

## 第 36—50 天：作者侧对抗与消融

- 对因果等价聚类阈值做敏感性分析；
- 替换 greedy clustering，验证结果是否依赖实现细节；
- 增加超过 8 个类时的可扩展对齐算法；
- 比较随机正交投影与学习型审计影子；
- 进行 null model、permutation、ablation；
- 发布至少 3 个 FAIL 或 PARTIAL 报告，不允许全通过才发布。

## 第 51—70 天：双盲独立复现

邀请至少两个相互独立团队：

- 团队 A 只获得协议和 schema；
- 团队 B 获得协议与参考代码，但必须更换模型和种子；
- 原作者在结果封存前不得查看中间指标；
- 所有差异通过预注册争议流程解释。

E5 只授予被独立复现的具体主张，不授予整个仓库。

## 第 71—80 天：生态压缩与旗舰漏斗

依据 ANTITHESIS 输出：

- 合并重复 claim clusters；
- 每条主航道选 1 个 flagship + 1 个 experimental branch；
- 其余仓库转为 archive、module 或 horizon-bank；
- 为每个 flagship 指定外部 reviewer 和失效日期；
- 禁止通过重新命名绕过失败历史。

## 第 81—90 天：公共发布与反证悬赏

发布：

- 机器可读 portfolio report；
- 全部 PASS/PARTIAL/FAIL；
- 独立复现差异；
- Merkle 根与签名；
- 最小决定性实验队列；
- 下一轮预算分配；
- 公开反证悬赏。

## 90 天成功标准

不是 stars、仓库数或文档页数，而是：

- 至少 1 条核心主张达到 E5；
- 至少 1 条核心主张因反证被正式缩窄或 RETIRE；
- 至少 30% 重复主张完成合并或 scope 区分；
- Φ0 ↔ Runtime 接口获得明确 PASS、PARTIAL 或 FAIL；
- 外部团队可以在不依赖原作者口头解释的情况下重跑关键协议；
- ANTITHESIS 自身仍未绕过独立复现门槛。
