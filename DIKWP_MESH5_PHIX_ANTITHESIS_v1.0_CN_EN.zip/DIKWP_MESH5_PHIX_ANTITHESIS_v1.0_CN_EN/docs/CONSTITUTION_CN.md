# ANTITHESIS 可执行科研与发布宪法 v1.0

## 序言

本宪法适用于 ANTITHESIS 管理的所有仓库、主张、实验、证据、接口和发布决策，也适用于 ANTITHESIS 自身。

目标不是证明某个理论永远正确，而是保证：

- 主张可被杀死；
- 失败可被保存；
- 决策可被撤回；
- 权力与证据不被混同；
- 同源成功不被包装成独立复现；
- 仓库数量不替代知识增量。

## 第一章：主张

### 第一条：逐主张登记

每个可影响设计、发布、资金、授权或现实行动的断言必须拥有唯一 claim ID。一个仓库可同时包含支持、争议、未检验和已反证主张。

### 第二条：最低字段

每条主张必须声明：

- text；
- scope；
- authority；
- purpose；
- assumptions；
- importance；
- risk；
- kill test；
- rollback。

缺少 scope、kill test 或 rollback 的核心主张强制 HOLD。

### 第三条：禁止仓库级证据洗白

以下推理无效：

- 仓库测试通过，所以仓库内全部理论成立；
- 代码开源，所以结果可复现；
- 来源可追溯，所以主张为真；
- stars 多，所以可信；
- 文档完整，所以现实有效。

## 第二章：证据

### 第四条：E0—E7

- E0：断言；
- E1：可追溯；
- E2：可执行；
- E3：内部重复验证；
- E4：对抗挑战；
- E5：独立复现；
- E6：跨情境验证；
- E7：持续审计。

### 第五条：同源折扣

来自同一 producer、同一数据管线或同一组织控制链的多份成功证据不得按完全独立证据相加。较强证据优先保留完整权重，后续同源证据递减折扣。

### 第六条：不利结果对称公开

PASS、PARTIAL、FAIL、CHALLENGE、FALSIFY 和 INCONCLUSIVE 必须进入同一账本。不得只发布成功种子、成功任务或成功模型。

### 第七条：反证优先

达到 E3 或更高执行强度的核心反证，可直接触发 RETIRE 或强制缩窄主张。不能用更多低级支持票抵消明确反证。

## 第三章：证伪合同

### 第八条：合同构成

每个核心主张必须拥有：

- hypothesis；
- null hypothesis；
- intervention；
- measurement；
- failure threshold；
- counterexample；
- stop condition；
- rollback；
- confounders；
- owner；
- cost；
- reversibility。

### 第九条：结果前冻结

关键 scope、baseline、failure threshold 和 evaluator 必须在观察结果前冻结。结果出现后修改，必须创建新版本主张，不得覆盖旧合同。

## 第四章：冲突与重复

### 第十条：冲突不是错误日志，而是实验资产

跨仓库冲突必须生成 joint bridge experiment，比较双方主张和可能的层次化解释。不得仅靠重新措辞把冲突消失。

### 第十一条：重复仓库必须支付差异证明

高度重叠的主张应：

- 合并；
- 明确不同 scope；
- 给出显著不同的可证伪预测；
- 或进入 RETIRE/ARCHIVE。

## 第五章：发布状态

### 第十二条：PROMOTE

最低条件：

- 所有核心主张至少 E5；
- credence 达到政策阈值；
- independence score 达到阈值；
- 无未解决关键冲突；
- kill/rollback 完整；
- 具有自动到期时间。

### 第十三条：PILOT

适用于内部 E3 充分、可回滚、scope 明确，但仍缺独立复现的系统。PILOT 不得宣传为普遍成立。

### 第十四条：REVIEW

适用于证据深度不足、存在未解决冲突或需要外部复现，但尚未构成运行安全阻断的系统。

### 第十五条：HOLD

以下任一情况触发 HOLD：

- 高风险核心主张没有 E2；
- 缺少 kill test；
- 缺少 rollback；
- authority、rights 或 stop condition 不完整；
- 数据完整性或账本验证失败。

### 第十六条：RETIRE

核心主张被足够强的执行证据反证时，原主张退役。允许创建缩窄 scope 的新版本，但必须继承失败记录和 residual。

## 第六章：自我适用

### 第十七条：ANTITHESIS 不得自我豁免

ANTITHESIS 的测试、账本、规划器和宪法同样按 E0—E7 评估。内部测试通过最多获得 PILOT。只有独立团队复现并对抗审查后，才可能 PROMOTE。

## 第七章：时效与撤回

### 第十八条：决策自动到期

默认 90 天。到期后若无新证据，状态回落到 REVIEW，不得永久继承历史晋级。

### 第十九条：可撤回优先于不可逆规模化

在证据不足时，优先选择小规模、可停止、可恢复的试点。不可逆行动必须由外部合法授权主体承担责任，系统不能自授现实权力。
