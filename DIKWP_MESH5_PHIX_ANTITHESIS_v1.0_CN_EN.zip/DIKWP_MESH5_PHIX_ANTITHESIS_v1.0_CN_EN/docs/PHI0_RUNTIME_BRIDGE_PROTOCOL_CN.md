# Φ0 ↔ MESH Runtime Commons 联合桥接证伪协议 v1.0

## 1. 待判定问题

Φ0 主张机器核心可基于下游因果等价对齐干预，而无需永久人类语义。MESH Runtime Commons 则提供 D/I/K/W/P 资源、25 类转换和多重索引的开发者运行时。

待判定的不是“哪个概念更高级”，而是：

> 能否建立一个不会污染 Φ0 核心、又能给人类和代理提供稳定审计与授权接口的有损语义见证层？

## 2. 预注册假设

### H1：可分层

Φ0 的等价类、operator lineage 和 residual reserve 在经过 DIKWP shadow 与 Runtime round-trip 后保持在预设容差内。

### H0：不可分层

语义见证层改变核心等价类、吞没残差、破坏 rollback，或使跨模型迁移显著恶化。

## 3. 实验对象

- 两个架构不同的开放权重模型；
- 一个冻结扰动族；
- 训练/校准/留出三部分任务；
- 至少 30 个种子或与功效分析一致的数量；
- 文本传递、embedding 传递作为外部基线。

模型、任务和阈值应在运行前写入 hash ledger。

## 4. 三条路径

### A. Φ0-only

不使用 D/I/K/W/P 语义字段，只用 opaque trace、effect signature、causal-equivalence class、XenoPacket 和 residual reserve。

### B. Runtime-only

使用 MESH Runtime 的资源类型、25 转换、索引、冲突与 residual ledger，禁止读取 Φ0 内部类标签。

### C. Layered bridge

```text
Φ0 causal core
  -> lossy DIKWP audit shadow
  -> temporary Runtime contract
  -> action / transfer
  -> rollback witness
  -> Φ0 consistency check
```

语义影子必须明确声明 projection loss 和 omitted dimensions。

## 5. 主要指标

- held-out transfer accuracy；
- baseline delta；
- cycle error；
- rollback error；
- equivalence-class stability；
- residual retention ratio；
- projection loss；
- semantic leakage score；
- 25-transform conformance；
- independent reproduction delta。

## 6. 失败阈值

以下任一条件触发 FAIL：

1. C 路径改变 Φ0 核心等价类超过预注册容差；
2. C 路径 residual retention 低于阈值；
3. rollback 不能恢复封存状态；
4. C 路径显著劣于 A 或 B，且差异不能由预注册成本解释；
5. 文本或 embedding 基线在留出模型对上稳定优于 Φ0；
6. 独立团队无法复现主要效果；
7. 结果依赖运行后新增定义或阈值。

## 7. PARTIAL 条件

可分层只在特定模型、扰动族或投影维度成立时，必须缩窄 scope，不得宣传为通用接口。

## 8. 回滚

- 隔离失败 bridge 版本；
- 保留全部 residual、失败种子与账本；
- Φ0 与 Runtime 分别维持独立发布；
- 创建新版本 bridge claim，不覆盖旧主张；
- 在新版本通过前禁止 PROMOTE。

## 9. 独立复现

独立团队必须：

- 不受原作者结果筛选控制；
- 更换至少一个模型和一组种子；
- 公开代码、环境、失败和差异；
- 对相同 claim ID 签发 E5 支持、挑战或反证回执。
