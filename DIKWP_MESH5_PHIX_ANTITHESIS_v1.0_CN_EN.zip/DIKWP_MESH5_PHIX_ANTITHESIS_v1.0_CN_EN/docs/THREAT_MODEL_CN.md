# ANTITHESIS 威胁模型

## 1. 保护对象

- 原始主张文本与版本；
- 证据来源、producer 和 independence；
- 不利结果、residual 与 contradiction；
- 发布决策及其条件；
- 实验合同和结果前冻结字段；
- 账本完整性；
- 高风险系统的停止与回滚权。

## 2. 主要威胁

### 2.1 证据洗白

把 README、stars、内部测试、多个同源种子或同组织复现包装为独立证据。

缓解：逐主张 E0—E7、producer 折扣、E5 明确独立性。

### 2.2 结果后改写主张

观察结果后修改 scope、baseline 或失败阈值，使任何结果都被解释为成功。

缓解：合同 hash、版本化 claim ID、旧版本不可覆盖。

### 2.3 失败删除

只保留通过回执，删除不利种子、未匹配残差或冲突。

缓解：append-only ledger、adverse-result obligation、Merkle 验证。

### 2.4 仓库爆炸绕过失败

主张失败后创建新仓库/新名称，不继承失败历史。

缓解：基于主张图的 duplicate cluster、lineage 和 scope 差异要求。

### 2.5 高风险原型被误用为现实授权

政策、医疗、安全或公共行动原型被当作自动决策权限。

缓解：高风险无 E2 强制 HOLD；MANDATE/authority/appeal/stop 字段；系统不执行现实动作。

### 2.6 账本篡改

修改历史 payload 或删除记录。

缓解：previous hash、payload hash、record hash、Merkle root、可选 HMAC。

### 2.7 自动冲突检测误报

词法相似或否定词造成假冲突。

缓解：所有自动关系带 inferred 和 confidence；高影响结论必须由 causal/领域审查替换；原推断保留但可撤回。

### 2.8 GitHub 导入供应链风险

恶意 README 或仓库代码诱导执行。

缓解：只读 API、严格 owner/repo 校验、不克隆、不安装、不执行第三方代码、README 仅 E1。

## 3. 非目标

当前版本不提供：

- 真实多方公钥透明日志；
- 身份认证与组织权限系统；
- 自动执行高风险实验；
- 通用语义理解；
- 对意识、真理或安全的终极证明；
- 法律或伦理授权替代品。

## 4. 安全报告

发现完整性、安全门禁或证据状态错误时，应：

1. 保存最小复现；
2. 记录受影响 claim/receipt/ledger ID；
3. 标记是否可能导致错误 PROMOTE；
4. 暂停受影响决策；
5. 修复后发布新版本和迁移说明；
6. 不删除原失败记录。
