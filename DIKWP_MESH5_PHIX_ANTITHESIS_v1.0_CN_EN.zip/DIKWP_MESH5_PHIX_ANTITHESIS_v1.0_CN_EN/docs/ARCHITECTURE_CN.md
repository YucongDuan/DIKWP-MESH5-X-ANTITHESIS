# ANTITHESIS 系统架构

## 1. 总体数据流

```mermaid
flowchart LR
    A[GitHub / 本地仓库 / Φ0 回执] --> B[Ingestion]
    B --> C[Claim Compiler]
    C --> D[Evidence Engine E0-E7]
    C --> E[Claim Graph]
    D --> E
    E --> F[Falsification Planner]
    D --> G[Release Constitution]
    F --> G
    G --> H[Hash Ledger + Merkle]
    H --> I[JSON Report / Dashboard / Action Queue]
```

核心原则：所有自动化推断都保留来源、版本、置信度与可撤回状态；任何推断都不能覆盖原始证据。

## 2. 模块说明

### `claim_compiler.py`

职责：

- 从 README 或人工输入中提取可检验断言；
- 推断能力、安全、治理、科学或基础设施类型；
- 计算可证伪性与过度主张风险；
- 为每条主张生成预注册式证伪合同。

自动提取是透明词法基线，不被描述为真正语义理解。

### `evidence.py`

职责：

- 映射 E0—E7；
- 按 producer/source 对同源证据折扣；
- 对支持、挑战、反证和未决回执分别更新；
- 计算 credence、independence score 和 claim status。

一个 E3 内部测试不会因为重复十次就变为 E5。

### `graph.py`

职责：

- 建立 supports、contradicts、duplicates、depends_on 图；
- 计算中心性；
- 找出重复簇、依赖闭环和未解决冲突；
- 为最小实验选择提供组合结构。

### `planner.py`

优先级由以下因素共同决定：

- 二元熵表示的不确定性；
- 主张重要性；
- 图中心性；
- 证伪力量；
- 独立性缺口；
- 风险；
- 可逆性；
- 成本惩罚。

它还会为跨仓库冲突生成 joint bridge experiment，而不是只给两边各自安排测试。

### `constitution.py`

发布状态：

- `PROMOTE`：独立复现、可信度和独立性门槛全部通过；
- `PILOT`：内部 E3 充分，但仍禁止外推；
- `REVIEW`：证据不足或存在未解决冲突；
- `HOLD`：高风险且缺少可执行证据，或缺少 kill/rollback；
- `RETIRE`：核心主张已被可执行证据反证。

所有状态自动到期，并携带恢复条件。

### `ledger.py`

每条记录包括：

- sequence；
- timestamp；
- event type；
- actor；
- previous hash；
- payload hash；
- record hash。

最终生成 Merkle root；可选 HMAC 用于本地封印。账本并不替代数字签名基础设施，但能检测交付包内的静默修改。

### `phi0_adapter.py`

适配 Φ0 的 `summary.json`、`experiments.json`、`conformance.json` 和 `residual_reserve.json`。

硬规则：

- 同一交付包的成功最多 E3；
- residual 只作为未决义务，不计为支持；
- adapter 不读取人类标签去改变 Φ0 核心结果；
- 没有外部复现时绝不输出 E5。

### `github.py`

只读 GitHub API 导入器：

- 拉取公开仓库元数据；
- 可选读取有限数量 README；
- 不克隆、不安装、不执行仓库；
- README 主张只生成 E1。

### `dashboard.py`

生成单文件离线 HTML：

- 无 CDN；
- 无外部 JavaScript；
- 可检索主张；
- 展示证据、冲突、决策、实验合同与账本根。

## 3. 核心对象

```text
Repository
  └── Claim[]
        ├── EvidenceItem[]
        ├── FalsificationContract
        └── ClaimRelation[]

ClaimAssessment
  ├── EvidenceLevel E0-E7
  ├── Credence
  ├── IndependenceScore
  └── Status

RepositoryDecision
  ├── PROMOTE/PILOT/REVIEW/HOLD/RETIRE
  ├── ReasonCodes
  ├── Conditions
  └── Expiry
```

## 4. 安全架构

- 默认 dry analysis；
- 不执行第三方仓库代码；
- 不接受任意 shell 作为实验合同；
- GitHub owner/repo 名称做严格字符校验；
- 所有写文件采用原子替换或 append+fsync；
- 报告和账本保留不利结果；
- 任何高风险主张缺 E2 时强制 HOLD。

## 5. 替换点

ANTITHESIS 有意将以下能力设计为可替换：

- 词法主张抽取 → 领域 LLM/人工标注；
- Jaccard 冲突基线 → 因果模型/嵌入模型/Φ0 对齐器；
- 简化 credence 更新 → 贝叶斯层级模型；
- 贪心预算规划 → 整数规划或主动学习；
- HMAC 封印 → 公钥签名与透明日志；
- 静态 HTML → 多组织联邦控制台。

替换时必须保留原始输出、版本和可回滚路径。
