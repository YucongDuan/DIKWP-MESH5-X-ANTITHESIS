# 交付验证方法

执行：

```bash
PYTHONPATH=src python tools/validate_release.py
```

验证项：

1. 27 项单元测试；
2. 12 项宪法一致性检查；
3. 演示报告关键不变量；
4. JSONL 账本完整性与 Merkle 根；
5. 全部 JSON 可解析；
6. JSON Schema 声明完整；
7. 离线仪表盘不依赖外部脚本；
8. Φ0 内部/合成证据不超过 E3；
9. wheel 可独立安装并通过 conformance。

关键不变量包括：

- 演示中 `PROMOTE = 0`；
- ANTITHESIS 自身最多 PILOT；
- 第一决定性实验为 Φ0 ↔ Runtime contradiction bridge；
- 账本篡改会被检测；
- 高风险 E1 系统必须 HOLD；
- 缺少 rollback 必须 HOLD。

隔离构建环境无法解析外部 DNS，因此 GitHub live API 调用标记为 SKIPPED，而不是伪造 PASS。GitHub importer 的输入校验和离线扫描路径由单元测试覆盖；发布后应在可联网环境执行一次只读 API smoke test。
