# ANTITHESIS architecture

ANTITHESIS compiles repositories into claim-level evidence and reversible release decisions:

```text
sources -> claim compiler -> E0-E7 evidence engine -> claim graph
        -> falsification planner -> release constitution -> hash ledger
        -> JSON reports and offline dashboard
```

The system deliberately separates traceability, executability, author-side replication, adversarial testing, independent replication, cross-context validation, and sustained audit.

Key modules:

- `claim_compiler.py`: deterministic claim extraction and kill-contract generation;
- `evidence.py`: evidence depth, source-independence discount, credence and status;
- `graph.py`: support, contradiction, duplication and dependency relations;
- `planner.py`: budget-bounded claim tests and joint contradiction-bridge experiments;
- `constitution.py`: PROMOTE/PILOT/REVIEW/HOLD/RETIRE gates;
- `ledger.py`: append-only hash chain, Merkle root and optional HMAC seal;
- `phi0_adapter.py`: conservative import of Φ0 synthetic/internal receipts;
- `github.py`: read-only GitHub metadata and README ingestion;
- `dashboard.py`: standalone offline report.

The lexical graph baseline is replaceable and must never be treated as semantic truth. High-impact use requires domain review and executable evidence.
