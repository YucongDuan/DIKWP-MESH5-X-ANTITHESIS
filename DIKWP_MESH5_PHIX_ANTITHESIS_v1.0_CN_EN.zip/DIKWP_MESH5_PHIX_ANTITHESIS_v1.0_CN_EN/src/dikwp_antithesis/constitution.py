from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

from .claim_compiler import ClaimCompiler
from .graph import ClaimGraph
from .models import (
    Claim,
    ClaimAssessment,
    ClaimStatus,
    DecisionState,
    EvidenceLevel,
    Repository,
    RepositoryDecision,
)
from .util import clamp


@dataclass(slots=True)
class ConstitutionPolicy:
    version: str = '1.0'
    critical_importance: float = 0.75
    high_risk: float = 0.70
    pilot_min_level: int = 3
    pilot_min_credence: float = 0.55
    promote_min_level: int = 5
    promote_min_credence: float = 0.72
    promote_min_independence: float = 0.55
    require_kill_test: bool = True
    require_rollback: bool = True
    require_adverse_publication: bool = True
    unresolved_critical_contradictions_max: int = 0
    decision_ttl_days: int = 90
    no_blanket_repo_evidence: bool = True
    laws: list[str] = field(
        default_factory=lambda: [
            'No claim without a kill test.',
            'No release without rollback.',
            'No flagship promotion without independent replication.',
            'Evidence state belongs to each claim, never to a repository as a whole.',
            'Contradictions, failures, and residuals are first-class records.',
            'Every promotion is reversible, scoped, and time-bounded.',
        ]
    )

    def __post_init__(self) -> None:
        self.critical_importance = clamp(self.critical_importance)
        self.high_risk = clamp(self.high_risk)
        self.pilot_min_credence = clamp(self.pilot_min_credence)
        self.promote_min_credence = clamp(self.promote_min_credence)
        self.promote_min_independence = clamp(self.promote_min_independence)

    @classmethod
    def from_dict(cls, value: dict) -> 'ConstitutionPolicy':
        return cls(**value)

    @classmethod
    def load(cls, path: str | Path) -> 'ConstitutionPolicy':
        with Path(path).open('r', encoding='utf-8') as handle:
            return cls.from_dict(json.load(handle))


class ReleaseConstitution:
    """Machine-checkable reversible release constitution."""

    def __init__(self, policy: ConstitutionPolicy | None = None) -> None:
        self.policy = policy or ConstitutionPolicy()
        self.compiler = ClaimCompiler()

    def evaluate_repository(
        self,
        repo: Repository,
        claims: Iterable[Claim],
        assessments: dict[str, ClaimAssessment],
        graph: ClaimGraph,
        *,
        as_of: datetime | None = None,
    ) -> RepositoryDecision:
        repo_claims = [claim for claim in claims if claim.repo_id == repo.id]
        current = as_of or datetime.now(timezone.utc)
        expires = (current + timedelta(days=self.policy.decision_ttl_days)).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
        if not repo_claims:
            return RepositoryDecision(
                repo_id=repo.id,
                state=DecisionState.HOLD,
                reason_codes=['NO_CLAIMS'],
                conditions=['Compile at least one scoped, falsifiable claim before release evaluation.'],
                core_claim_ids=[],
                expires_at=expires,
                policy_version=self.policy.version,
                metrics={'claim_count': 0},
            )

        core = [claim for claim in repo_claims if claim.importance >= self.policy.critical_importance]
        if not core:
            core = [max(repo_claims, key=lambda claim: claim.importance)]
        core_assessments = [assessments[claim.id] for claim in core]
        core_ids = {claim.id for claim in core}
        missing_kill = [claim.id for claim in core if self.policy.require_kill_test and not claim.kill_test.strip()]
        missing_rollback = [claim.id for claim in core if self.policy.require_rollback and not claim.rollback.strip()]
        tax_violations = {claim.id: self.compiler.evidence_tax(claim) for claim in core}
        critical_tax = {
            claim_id: violations
            for claim_id, violations in tax_violations.items()
            if any(code in {'MISSING_KILL_TEST', 'MISSING_ROLLBACK', 'MISSING_SCOPE'} for code in violations)
        }
        contradictions = [
            relation
            for relation in graph.unresolved_contradictions(assessments)
            if relation.source_claim_id in core_ids or relation.target_claim_id in core_ids
        ]
        falsified = [item for item in core_assessments if item.status == ClaimStatus.FALSIFIED]
        min_level = min(int(item.evidence_level) for item in core_assessments)
        min_credence = min(item.credence for item in core_assessments)
        avg_credence = sum(item.credence for item in core_assessments) / len(core_assessments)
        min_independence = min(item.independence_score for item in core_assessments)
        executable_coverage = sum(
            1 for item in core_assessments if item.evidence_level >= EvidenceLevel.E2_EXECUTABLE
        ) / len(core_assessments)
        conditions: list[str] = []
        reasons: list[str] = []

        if falsified:
            state = DecisionState.RETIRE
            reasons.append('CORE_CLAIM_FALSIFIED')
            conditions.append('Preserve the adverse receipts; retire the broad claim or replace it with a narrower, newly versioned claim.')
        elif critical_tax or missing_kill or missing_rollback:
            state = DecisionState.HOLD
            reasons.append('CONSTITUTIONAL_FIELDS_MISSING')
            if missing_kill:
                conditions.append(f'Attach executable kill tests to core claims: {", ".join(sorted(missing_kill))}.')
            if missing_rollback:
                conditions.append(f'Attach reversible rollback procedures to core claims: {", ".join(sorted(missing_rollback))}.')
        elif repo.risk_level >= self.policy.high_risk and executable_coverage < 1.0:
            state = DecisionState.HOLD
            reasons.append('HIGH_RISK_WITHOUT_EXECUTABLE_EVIDENCE')
            conditions.append('Produce E2 executable evidence for every high-risk core claim inside a bounded sandbox.')
        elif len(contradictions) > self.policy.unresolved_critical_contradictions_max:
            state = DecisionState.REVIEW
            reasons.append('UNRESOLVED_CRITICAL_CONTRADICTION')
            conditions.append('Run a decisive matched-scope experiment for each unresolved critical contradiction.')
        elif (
            min_level >= self.policy.promote_min_level
            and min_credence >= self.policy.promote_min_credence
            and min_independence >= self.policy.promote_min_independence
        ):
            state = DecisionState.PROMOTE
            reasons.append('CLAIM_LEVEL_PROMOTION_GATE_PASSED')
            conditions.append('Promotion expires automatically; renew only with fresh adverse-case and drift evidence.')
        elif min_level >= self.policy.pilot_min_level and min_credence >= self.policy.pilot_min_credence:
            state = DecisionState.PILOT
            reasons.append('INTERNAL_PILOT_GATE_PASSED')
            if min_level < self.policy.promote_min_level or min_independence < self.policy.promote_min_independence:
                conditions.append('Independent replication is mandatory before PROMOTE; internal passing tests remain E3.')
        else:
            state = DecisionState.REVIEW
            reasons.append('EVIDENCE_DEPTH_INSUFFICIENT')
            conditions.append('Execute the highest-information kill test and publish PASS, PARTIAL, or FAIL without selective omission.')

        if any(float(claim.metadata.get('overclaim_risk', 0.0)) >= 0.65 for claim in core):
            reasons.append('OVERCLAIM_RISK_PRESENT')
            conditions.append('Narrow absolute or universal language to the tested scope before external release.')
        if min_independence < self.policy.promote_min_independence:
            reasons.append('INDEPENDENCE_BELOW_PROMOTION_GATE')
        if not conditions:
            conditions.append('Maintain append-only receipts, named boundaries, and a tested rollback for the decision lifetime.')

        metrics = {
            'claim_count': len(repo_claims),
            'core_claim_count': len(core),
            'minimum_core_evidence_level': min_level,
            'minimum_core_credence': round(min_credence, 6),
            'average_core_credence': round(avg_credence, 6),
            'minimum_core_independence': round(min_independence, 6),
            'executable_core_coverage': round(executable_coverage, 6),
            'unresolved_critical_contradictions': len(contradictions),
            'evidence_tax_violations': sum(len(value) for value in tax_violations.values()),
        }
        return RepositoryDecision(
            repo_id=repo.id,
            state=state,
            reason_codes=list(dict.fromkeys(reasons)),
            conditions=list(dict.fromkeys(conditions)),
            core_claim_ids=[claim.id for claim in core],
            expires_at=expires,
            reversible=True,
            policy_version=self.policy.version,
            metrics=metrics,
        )

    def evaluate_all(
        self,
        repositories: Iterable[Repository],
        claims: Iterable[Claim],
        assessments: dict[str, ClaimAssessment],
        graph: ClaimGraph,
        *,
        as_of: datetime | None = None,
    ) -> list[RepositoryDecision]:
        claim_list = list(claims)
        decisions = [
            self.evaluate_repository(repo, claim_list, assessments, graph, as_of=as_of)
            for repo in repositories
        ]
        order = {
            DecisionState.RETIRE: 0,
            DecisionState.HOLD: 1,
            DecisionState.REVIEW: 2,
            DecisionState.PILOT: 3,
            DecisionState.PROMOTE: 4,
        }
        return sorted(decisions, key=lambda item: (order[item.state], item.repo_id))
