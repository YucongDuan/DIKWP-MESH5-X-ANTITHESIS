from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum, IntEnum
from typing import Any

from .util import clamp


class EvidenceLevel(IntEnum):
    E0_ASSERTION = 0
    E1_TRACEABLE = 1
    E2_EXECUTABLE = 2
    E3_INTERNAL_REPLICATION = 3
    E4_ADVERSARIAL = 4
    E5_INDEPENDENT_REPLICATION = 5
    E6_CROSS_CONTEXT = 6
    E7_SUSTAINED_AUDIT = 7

    @classmethod
    def parse(cls, value: int | str | 'EvidenceLevel') -> 'EvidenceLevel':
        if isinstance(value, cls):
            return value
        if isinstance(value, int):
            return cls(value)
        text = str(value).strip().upper()
        if text.isdigit():
            return cls(int(text))
        if text.startswith('E') and text[1:2].isdigit():
            return cls(int(text[1]))
        return cls[text]


class EvidenceResult(str, Enum):
    SUPPORT = 'support'
    CHALLENGE = 'challenge'
    FALSIFY = 'falsify'
    INCONCLUSIVE = 'inconclusive'


class ClaimStatus(str, Enum):
    UNTESTED = 'UNTESTED'
    SUPPORTED = 'SUPPORTED'
    CONTESTED = 'CONTESTED'
    FALSIFIED = 'FALSIFIED'


class RelationKind(str, Enum):
    SUPPORTS = 'supports'
    CONTRADICTS = 'contradicts'
    DUPLICATES = 'duplicates'
    DEPENDS_ON = 'depends_on'


class DecisionState(str, Enum):
    PROMOTE = 'PROMOTE'
    PILOT = 'PILOT'
    REVIEW = 'REVIEW'
    HOLD = 'HOLD'
    RETIRE = 'RETIRE'


@dataclass(slots=True)
class Repository:
    id: str
    name: str
    url: str = ''
    description: str = ''
    mission: str = ''
    tags: list[str] = field(default_factory=list)
    updated_at: str = ''
    risk_level: float = 0.5
    flagship: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.risk_level = clamp(self.risk_level)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> 'Repository':
        return cls(**value)


@dataclass(slots=True)
class Claim:
    id: str
    repo_id: str
    text: str
    claim_type: str = 'capability'
    scope: str = 'prototype'
    importance: float = 0.5
    risk: float = 0.5
    falsifiability: float = 0.5
    kill_test: str = ''
    rollback: str = ''
    assumptions: list[str] = field(default_factory=list)
    authority: str = ''
    purpose: str = ''
    status: ClaimStatus = ClaimStatus.UNTESTED
    expires_at: str = ''
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.importance = clamp(self.importance)
        self.risk = clamp(self.risk)
        self.falsifiability = clamp(self.falsifiability)
        if not isinstance(self.status, ClaimStatus):
            self.status = ClaimStatus(str(self.status))

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> 'Claim':
        return cls(**value)


@dataclass(slots=True)
class EvidenceItem:
    id: str
    claim_id: str
    level: EvidenceLevel
    result: EvidenceResult
    source: str
    producer: str
    timestamp: str = ''
    independent_of: list[str] = field(default_factory=list)
    reproducible: bool = False
    checksum: str = ''
    context: str = ''
    notes: str = ''
    metrics: dict[str, float | int | str | bool] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.level = EvidenceLevel.parse(self.level)
        if not isinstance(self.result, EvidenceResult):
            self.result = EvidenceResult(str(self.result).lower())

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> 'EvidenceItem':
        return cls(**value)


@dataclass(slots=True)
class ClaimRelation:
    source_claim_id: str
    target_claim_id: str
    kind: RelationKind
    confidence: float = 1.0
    rationale: str = ''
    inferred: bool = False

    def __post_init__(self) -> None:
        self.confidence = clamp(self.confidence)
        if not isinstance(self.kind, RelationKind):
            self.kind = RelationKind(str(self.kind))

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> 'ClaimRelation':
        return cls(**value)


@dataclass(slots=True)
class FalsificationContract:
    id: str
    claim_id: str
    hypothesis: str
    null_hypothesis: str
    intervention: str
    measurement: str
    failure_threshold: str
    counterexample: str
    stop_condition: str
    rollback: str
    confounders: list[str] = field(default_factory=list)
    owner: str = ''
    due_date: str = ''
    estimated_cost: float = 1.0
    reversibility: float = 1.0
    falsification_power: float = 0.5
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.estimated_cost = max(0.01, float(self.estimated_cost))
        self.reversibility = clamp(self.reversibility)
        self.falsification_power = clamp(self.falsification_power)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> 'FalsificationContract':
        return cls(**value)


@dataclass(slots=True)
class ClaimAssessment:
    claim_id: str
    evidence_level: EvidenceLevel
    credence: float
    independence_score: float
    status: ClaimStatus
    support_weight: float
    challenge_weight: float
    evidence_count: int
    rationale: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.evidence_level = EvidenceLevel.parse(self.evidence_level)
        self.credence = clamp(self.credence)
        self.independence_score = clamp(self.independence_score)
        if not isinstance(self.status, ClaimStatus):
            self.status = ClaimStatus(str(self.status))


@dataclass(slots=True)
class ExperimentPlan:
    rank: int
    contract_id: str
    claim_id: str
    repo_id: str
    score: float
    expected_information_gain: float
    priority_reasons: list[str]
    estimated_cost: float
    stop_condition: str
    decision_unlocked: str
    target_claim_ids: list[str] = field(default_factory=list)
    experiment_type: str = 'claim-kill-test'
    intervention: str = ''
    measurement: str = ''
    failure_threshold: str = ''
    rollback: str = ''


@dataclass(slots=True)
class RepositoryDecision:
    repo_id: str
    state: DecisionState
    reason_codes: list[str]
    conditions: list[str]
    core_claim_ids: list[str]
    expires_at: str
    reversible: bool = True
    policy_version: str = '1.0'
    metrics: dict[str, float | int | str | bool] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.state, DecisionState):
            self.state = DecisionState(str(self.state))


@dataclass(slots=True)
class Portfolio:
    repositories: list[Repository] = field(default_factory=list)
    claims: list[Claim] = field(default_factory=list)
    evidence: list[EvidenceItem] = field(default_factory=list)
    relations: list[ClaimRelation] = field(default_factory=list)
    contracts: list[FalsificationContract] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> 'Portfolio':
        return cls(
            repositories=[Repository.from_dict(item) for item in value.get('repositories', [])],
            claims=[Claim.from_dict(item) for item in value.get('claims', [])],
            evidence=[EvidenceItem.from_dict(item) for item in value.get('evidence', [])],
            relations=[ClaimRelation.from_dict(item) for item in value.get('relations', [])],
            contracts=[FalsificationContract.from_dict(item) for item in value.get('contracts', [])],
            metadata=value.get('metadata', {}),
        )

    def to_dict(self) -> dict[str, Any]:
        return to_dict(self)


def to_dict(value: Any) -> Any:
    if isinstance(value, Enum):
        if isinstance(value, IntEnum):
            return int(value)
        return value.value
    if hasattr(value, '__dataclass_fields__'):
        return {key: to_dict(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {key: to_dict(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_dict(item) for item in value]
    return value
