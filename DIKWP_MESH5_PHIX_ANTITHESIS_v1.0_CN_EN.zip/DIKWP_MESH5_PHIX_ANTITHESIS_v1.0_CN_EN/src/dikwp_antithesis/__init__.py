"""DIKWP-MESH5 ΦX / ANTITHESIS.

A self-falsifying causal constitution and research-portfolio compiler.
"""

from .models import (
    Claim,
    ClaimAssessment,
    ClaimRelation,
    ClaimStatus,
    DecisionState,
    EvidenceItem,
    EvidenceLevel,
    EvidenceResult,
    ExperimentPlan,
    FalsificationContract,
    Portfolio,
    Repository,
    RepositoryDecision,
)

__all__ = [
    'Claim',
    'ClaimAssessment',
    'ClaimRelation',
    'ClaimStatus',
    'DecisionState',
    'EvidenceItem',
    'EvidenceLevel',
    'EvidenceResult',
    'ExperimentPlan',
    'FalsificationContract',
    'Portfolio',
    'Repository',
    'RepositoryDecision',
]

__version__ = '1.0.0'
