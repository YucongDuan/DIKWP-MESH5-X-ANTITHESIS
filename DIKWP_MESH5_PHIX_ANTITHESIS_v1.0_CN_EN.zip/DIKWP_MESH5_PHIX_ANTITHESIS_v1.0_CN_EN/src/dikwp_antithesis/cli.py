from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .conformance import run_conformance
from .constitution import ConstitutionPolicy
from .dashboard import DashboardGenerator
from .demo_data import build_demo_portfolio
from .github import GitHubClient, LocalRepositoryScanner
from .ledger import HashLedger
from .models import Portfolio
from .phi0_adapter import Phi0Adapter
from .portfolio import PortfolioCompiler
from .util import read_json, write_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog='dikwp-antithesis',
        description='DIKWP-MESH5 ΦX self-falsifying research portfolio compiler',
    )
    sub = parser.add_subparsers(dest='command', required=True)

    demo = sub.add_parser('demo', help='run the curated YucongDuan + ANTITHESIS + optional Φ0 demonstration')
    demo.add_argument('--out', default='outputs/demo')
    demo.add_argument('--phi0', help='path to a Φ0 output directory containing summary.json')
    _add_compile_options(demo)

    compile_cmd = sub.add_parser('compile', help='compile a portfolio JSON document')
    compile_cmd.add_argument('--input', required=True)
    compile_cmd.add_argument('--out', required=True)
    _add_compile_options(compile_cmd)

    phi0 = sub.add_parser('phi0', help='import and constitutionally evaluate a DIKWP-MESH5 Φ0 output directory')
    phi0.add_argument('--input', required=True)
    phi0.add_argument('--out', required=True)
    phi0.add_argument('--repo-url', default='')
    _add_compile_options(phi0)

    github = sub.add_parser('github', help='read-only import of a public GitHub owner portfolio')
    github.add_argument('--owner', required=True)
    github.add_argument('--out', required=True)
    github.add_argument('--readme-limit', type=int, default=30)
    github.add_argument('--max-claims-per-repo', type=int, default=12)
    _add_compile_options(github)

    scan = sub.add_parser('scan', help='offline scan of local repository directories')
    scan.add_argument('paths', nargs='+')
    scan.add_argument('--out', required=True)
    scan.add_argument('--max-claims-per-repo', type=int, default=20)
    _add_compile_options(scan)

    conformance = sub.add_parser('conformance', help='run constitutional self-tests')
    conformance.add_argument('--out')

    verify = sub.add_parser('verify-ledger', help='verify an ANTITHESIS JSONL hash ledger')
    verify.add_argument('--input', required=True)

    dashboard = sub.add_parser('dashboard', help='generate an offline dashboard from portfolio_report.json')
    dashboard.add_argument('--report', required=True)
    dashboard.add_argument('--out', required=True)
    return parser


def _add_compile_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument('--policy', help='constitution policy JSON; defaults to built-in policy')
    parser.add_argument('--budget', type=float, default=60.0)
    parser.add_argument('--max-experiments', type=int, default=12)
    parser.add_argument('--as-of', default='2026-07-22T12:00:00Z')


def _parse_time(value: str) -> datetime:
    text = value.strip().replace('Z', '+00:00')
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _compiler(policy_path: str | None) -> PortfolioCompiler:
    policy = ConstitutionPolicy.load(policy_path) if policy_path else None
    return PortfolioCompiler(policy=policy)


def _compile_and_write(portfolio: Portfolio, args: argparse.Namespace) -> dict:
    output = Path(args.out)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / 'input_portfolio.json', portfolio.to_dict())
    compiler = _compiler(args.policy)
    report = compiler.compile(
        portfolio,
        budget=args.budget,
        max_experiments=args.max_experiments,
        as_of=_parse_time(args.as_of),
    )
    paths = compiler.write_outputs(report, output)
    dashboard_path = DashboardGenerator().generate(report, output / 'dashboard.html')
    paths['dashboard'] = str(dashboard_path)
    return {'summary': report['summary'], 'paths': paths, 'ledger': report['ledger_verification']}


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == 'demo':
            result = _compile_and_write(build_demo_portfolio(args.phi0), args)
        elif args.command == 'compile':
            portfolio = Portfolio.from_dict(read_json(args.input))
            result = _compile_and_write(portfolio, args)
        elif args.command == 'phi0':
            portfolio = Phi0Adapter().import_directory(args.input, repo_url=args.repo_url)
            result = _compile_and_write(portfolio, args)
        elif args.command == 'github':
            portfolio = GitHubClient().owner_portfolio(
                args.owner,
                readme_limit=max(0, args.readme_limit),
                max_claims_per_repo=max(1, args.max_claims_per_repo),
            )
            result = _compile_and_write(portfolio, args)
        elif args.command == 'scan':
            portfolio = LocalRepositoryScanner().scan(
                args.paths,
                max_claims_per_repo=max(1, args.max_claims_per_repo),
            )
            result = _compile_and_write(portfolio, args)
        elif args.command == 'conformance':
            result = run_conformance()
            if args.out:
                write_json(args.out, result)
        elif args.command == 'verify-ledger':
            result = HashLedger.load(args.input).verify()
        elif args.command == 'dashboard':
            report = read_json(args.report)
            DashboardGenerator().generate(report, args.out)
            result = {'dashboard': str(Path(args.out).resolve())}
        else:  # pragma: no cover
            raise ValueError(f'Unknown command: {args.command}')
    except Exception as exc:
        error = {'status': 'ERROR', 'type': type(exc).__name__, 'message': str(exc)}
        print(json.dumps(error, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0
