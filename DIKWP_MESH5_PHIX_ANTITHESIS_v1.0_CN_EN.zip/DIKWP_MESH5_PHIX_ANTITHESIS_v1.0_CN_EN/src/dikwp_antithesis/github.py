from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Iterable

from .claim_compiler import ClaimCompiler
from .models import EvidenceItem, EvidenceLevel, EvidenceResult, Portfolio, Repository
from .util import stable_id


class GitHubError(RuntimeError):
    pass


class GitHubClient:
    """Small GitHub REST client; read-only and token-optional."""

    API_BASE = 'https://api.github.com'
    IDENTIFIER = re.compile(r'^[A-Za-z0-9_.-]{1,100}$')

    def __init__(self, token: str | None = None, timeout: float = 20.0) -> None:
        self.token = token or os.getenv('GITHUB_TOKEN', '')
        self.timeout = timeout

    def list_repositories(self, owner: str, *, max_pages: int = 10, per_page: int = 100) -> list[dict[str, Any]]:
        self._validate_identifier(owner, 'owner')
        repositories: list[dict[str, Any]] = []
        for page in range(1, max_pages + 1):
            query = urllib.parse.urlencode(
                {'per_page': min(100, max(1, per_page)), 'page': page, 'sort': 'updated', 'direction': 'desc'}
            )
            batch = self._json(f'/users/{owner}/repos?{query}')
            if not isinstance(batch, list):
                raise GitHubError('GitHub repository response was not a list')
            repositories.extend(batch)
            if len(batch) < per_page:
                break
        return repositories

    def fetch_readme(self, owner: str, repo: str) -> str:
        self._validate_identifier(owner, 'owner')
        self._validate_identifier(repo, 'repository')
        return self._text(
            f'/repos/{owner}/{repo}/readme',
            accept='application/vnd.github.raw+json',
        )

    def owner_portfolio(
        self,
        owner: str,
        *,
        readme_limit: int = 30,
        max_claims_per_repo: int = 12,
    ) -> Portfolio:
        raw_repositories = self.list_repositories(owner)
        compiler = ClaimCompiler()
        repositories: list[Repository] = []
        claims = []
        contracts = []
        evidence = []
        for index, raw in enumerate(raw_repositories):
            repo_id = stable_id('REPO', owner, raw.get('name', ''))
            repository = Repository(
                id=repo_id,
                name=str(raw.get('name', '')),
                url=str(raw.get('html_url', '')),
                description=str(raw.get('description') or ''),
                mission=str(raw.get('description') or ''),
                tags=list(raw.get('topics') or []),
                updated_at=str(raw.get('updated_at') or ''),
                risk_level=0.5,
                flagship=False,
                metadata={
                    'stars': int(raw.get('stargazers_count') or 0),
                    'forks': int(raw.get('forks_count') or 0),
                    'archived': bool(raw.get('archived')),
                    'default_branch': str(raw.get('default_branch') or ''),
                    'github_id': raw.get('id'),
                },
            )
            repositories.append(repository)
            if index >= readme_limit or repository.metadata['archived']:
                continue
            try:
                readme = self.fetch_readme(owner, repository.name)
            except GitHubError as exc:
                repository.metadata['readme_error'] = str(exc)
                continue
            extracted = compiler.extract_markdown(
                readme,
                repo_id,
                authority=f'{owner}/{repository.name} maintainers',
                purpose=repository.mission or 'Public repository purpose as declared in README.',
                max_claims=max_claims_per_repo,
            )
            compiled, repo_contracts = compiler.compile_many(extracted)
            claims.extend(compiled)
            contracts.extend(repo_contracts)
            for claim in compiled:
                evidence.append(
                    EvidenceItem(
                        id=stable_id('EVD', claim.id, 'github-readme'),
                        claim_id=claim.id,
                        level=EvidenceLevel.E1_TRACEABLE,
                        result=EvidenceResult.SUPPORT,
                        source=f'{repository.url}#readme',
                        producer=f'{owner}/{repository.name}',
                        reproducible=False,
                        context='Traceable public assertion extracted from README; not execution or replication evidence.',
                        notes='E1 only. The repository assertion is not upgraded merely because code is public.',
                        metadata={'independent': False, 'source_kind': 'github-readme'},
                    )
                )
        return Portfolio(
            repositories=repositories,
            claims=claims,
            evidence=evidence,
            contracts=contracts,
            metadata={
                'source': f'https://github.com/{owner}',
                'owner': owner,
                'repository_count': len(repositories),
                'readmes_scanned': min(readme_limit, len(repositories)),
                'caveat': 'README assertions are classified E1 until executable or replication receipts are attached.',
            },
        )

    def _json(self, path: str) -> Any:
        payload = self._request(path, accept='application/vnd.github+json')
        try:
            return json.loads(payload)
        except json.JSONDecodeError as exc:
            raise GitHubError(f'Invalid JSON from GitHub: {exc}') from exc

    def _text(self, path: str, *, accept: str) -> str:
        return self._request(path, accept=accept)

    def _request(self, path: str, *, accept: str) -> str:
        url = path if path.startswith('https://') else self.API_BASE + path
        headers = {
            'Accept': accept,
            'User-Agent': 'DIKWP-ANTITHESIS/1.0',
            'X-GitHub-Api-Version': '2022-11-28',
        }
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        request = urllib.request.Request(url, headers=headers, method='GET')
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as exc:
            body = exc.read().decode('utf-8', errors='replace')[:500]
            raise GitHubError(f'GitHub HTTP {exc.code}: {body}') from exc
        except urllib.error.URLError as exc:
            raise GitHubError(f'GitHub network error: {exc.reason}') from exc

    @classmethod
    def _validate_identifier(cls, value: str, label: str) -> None:
        if not cls.IDENTIFIER.fullmatch(value):
            raise ValueError(f'Invalid GitHub {label}: {value!r}')


class LocalRepositoryScanner:
    """Offline scanner for a directory containing local repository folders."""

    def scan(self, roots: Iterable[str | Path], *, max_claims_per_repo: int = 20) -> Portfolio:
        compiler = ClaimCompiler()
        repositories: list[Repository] = []
        claims = []
        contracts = []
        evidence = []
        for root_value in roots:
            root = Path(root_value).resolve()
            if not root.exists() or not root.is_dir():
                continue
            readme = self._find_readme(root)
            repo_id = stable_id('REPO', str(root))
            repo = Repository(
                id=repo_id,
                name=root.name,
                url=root.as_uri(),
                description='',
                mission='',
                updated_at='',
                risk_level=0.5,
                metadata={'local_path': str(root), 'readme': str(readme) if readme else ''},
            )
            repositories.append(repo)
            if not readme:
                continue
            text = readme.read_text(encoding='utf-8', errors='replace')
            extracted = compiler.extract_markdown(
                text,
                repo_id,
                authority=f'local maintainers of {root.name}',
                purpose='Purpose declared in the local README.',
                max_claims=max_claims_per_repo,
            )
            compiled, repo_contracts = compiler.compile_many(extracted)
            claims.extend(compiled)
            contracts.extend(repo_contracts)
            for claim in compiled:
                evidence.append(
                    EvidenceItem(
                        id=stable_id('EVD', claim.id, readme),
                        claim_id=claim.id,
                        level=EvidenceLevel.E1_TRACEABLE,
                        result=EvidenceResult.SUPPORT,
                        source=str(readme),
                        producer=root.name,
                        context='Local README assertion only.',
                    )
                )
        return Portfolio(repositories, claims, evidence, [], contracts, {'mode': 'local-offline-scan'})

    @staticmethod
    def _find_readme(root: Path) -> Path | None:
        for name in ('README.md', 'README_CN.md', 'README_EN.md', 'readme.md'):
            candidate = root / name
            if candidate.exists():
                return candidate
        return None
