from __future__ import annotations

import hashlib
import json
import math
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_text(canonical_json(value))


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def sigmoid(value: float) -> float:
    if value >= 0:
        z = math.exp(-value)
        return 1.0 / (1.0 + z)
    z = math.exp(value)
    return z / (1.0 + z)


def logit(probability: float) -> float:
    p = clamp(probability, 1e-9, 1.0 - 1e-9)
    return math.log(p / (1.0 - p))


def binary_entropy(probability: float) -> float:
    p = clamp(probability, 1e-12, 1.0 - 1e-12)
    return -(p * math.log2(p) + (1.0 - p) * math.log2(1.0 - p))


def stable_id(prefix: str, *parts: Any, length: int = 14) -> str:
    digest = sha256_text('|'.join(str(part) for part in parts))[:length]
    return f'{prefix}-{digest}'


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r'[^a-z0-9\u4e00-\u9fff]+', '-', value)
    return value.strip('-') or 'item'


def tokenize(text: str) -> set[str]:
    """Deterministic multilingual lexical baseline.

    English-like sequences are lower-cased words. CJK text is represented by
    overlapping 2-character grams. It is intentionally not called a semantic
    model; downstream users may replace it with an embedding or Φ0 adapter.
    """
    lowered = text.lower()
    latin = set(re.findall(r"[a-z0-9][a-z0-9_\-]{1,}", lowered))
    cjk_runs = re.findall(r'[\u3400-\u9fff]+', lowered)
    cjk: set[str] = set()
    for run in cjk_runs:
        if len(run) == 1:
            cjk.add(run)
        else:
            cjk.update(run[i : i + 2] for i in range(len(run) - 1))
    stop = {
        'the', 'and', 'for', 'with', 'that', 'this', 'from', 'into', 'are', 'was',
        'will', 'can', 'not', 'its', 'our', 'your', 'their', 'a', 'an', 'of', 'to',
        'in', 'on', 'by', 'or', 'as', 'is', 'be', 'it', 'we', 'at',
    }
    return (latin - stop) | cjk


def jaccard(left: Iterable[str], right: Iterable[str]) -> float:
    a, b = set(left), set(right)
    if not a and not b:
        return 1.0
    union = a | b
    return len(a & b) / len(union) if union else 0.0


def read_json(path: str | Path) -> Any:
    with Path(path).open('r', encoding='utf-8') as handle:
        return json.load(handle)


def write_json(path: str | Path, value: Any, *, indent: int = 2) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, indent=indent, sort_keys=True, default=str) + '\n'
    atomic_write_text(target, payload)


def atomic_write_text(path: str | Path, text: str) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f'.{target.name}.', dir=str(target.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, target)
    except Exception:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise
