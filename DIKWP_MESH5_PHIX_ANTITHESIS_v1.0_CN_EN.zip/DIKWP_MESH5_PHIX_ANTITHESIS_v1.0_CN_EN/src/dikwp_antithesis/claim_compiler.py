from __future__ import annotations

import re
from dataclasses import replace
from typing import Iterable

from .models import Claim, FalsificationContract
from .util import clamp, stable_id, tokenize


class ClaimCompiler:
    """Compile prose assertions into machine-checkable claim and kill-test records.

    This compiler is deliberately conservative and deterministic. It exposes
    its lexical heuristics instead of presenting them as semantic truth.
    """

    VERSION = '1.0'

    ASSERTION_MARKERS = (
        'implements', 'provides', 'supports', 'enables', 'ensures', 'guarantees',
        'achieves', 'outperforms', 'prevents', 'detects', 'aligns', 'transfers',
        'is a ', 'is an ', 'can ', 'will ', 'must ', 'allows', 'proves',
        '实现', '提供', '支持', '确保', '保证', '达到', '优于', '防止', '检测',
        '对齐', '迁移', '能够', '可以', '必须', '证明', '用于', '目标是', '形成',
    )
    ABSOLUTE_MARKERS = (
        'always', 'never', 'guarantee', 'universal', 'complete', 'fully', 'perfect',
        'proof of consciousness', 'safe', 'trustworthy', 'solves', 'eliminates',
        '永远', '绝不', '保证', '通用', '完全', '完美', '意识证明', '安全', '可信',
        '彻底解决', '消除', '必然', '唯一',
    )
    LIMITATION_MARKERS = (
        'prototype', 'offline', 'synthetic', 'reference implementation', 'does not',
        'not a proof', 'boundary', 'limitation', 'pilot', 'closed-world', 'baseline',
        '原型', '离线', '合成', '参考实现', '不代表', '不是证明', '边界', '限制',
        '试点', '封闭世界', '基线', '仅',
    )
    MEASUREMENT_MARKERS = (
        '%', 'accuracy', 'error', 'latency', 'throughput', 'rate', 'threshold', 'score',
        'benchmark', 'test', 'metric', 'pass', 'fail', 'replication', 'audit',
        '准确率', '误差', '延迟', '吞吐', '比率', '阈值', '评分', '基准', '测试',
        '指标', '通过', '失败', '复现', '审计',
    )

    def extract_markdown(
        self,
        markdown: str,
        repo_id: str,
        *,
        authority: str = '',
        purpose: str = '',
        max_claims: int = 40,
    ) -> list[Claim]:
        cleaned = self._strip_non_prose(markdown)
        heading = ''
        candidates: list[tuple[str, str]] = []
        paragraph: list[str] = []

        def flush_paragraph() -> None:
            if paragraph:
                text = ' '.join(paragraph).strip()
                candidates.extend((sentence, heading) for sentence in self._sentences(text))
                paragraph.clear()

        for raw in cleaned.splitlines():
            line = raw.strip()
            if not line:
                flush_paragraph()
                continue
            if line.startswith('#'):
                flush_paragraph()
                heading = line.lstrip('#').strip()
                continue
            if line.startswith(('-', '*', '+')):
                flush_paragraph()
                item = re.sub(r'^[-*+]\s+', '', line)
                candidates.extend((sentence, heading) for sentence in self._sentences(item))
                continue
            if re.match(r'^\d+[.)]\s+', line):
                flush_paragraph()
                item = re.sub(r'^\d+[.)]\s+', '', line)
                candidates.extend((sentence, heading) for sentence in self._sentences(item))
                continue
            paragraph.append(line)
        flush_paragraph()

        claims: list[Claim] = []
        seen: set[str] = set()
        for text, source_heading in candidates:
            normalized = re.sub(r'\s+', ' ', text).strip(' -—:：')
            if not self._is_candidate(normalized):
                continue
            fingerprint = ' '.join(sorted(tokenize(normalized)))
            if not fingerprint or fingerprint in seen:
                continue
            seen.add(fingerprint)
            claim_type = self.infer_type(normalized, source_heading)
            falsifiability = self.score_falsifiability(normalized)
            overclaim = self.score_overclaim_risk(normalized)
            importance = self.score_importance(normalized, source_heading)
            risk = self.score_risk(normalized, claim_type)
            claim_id = stable_id('CLM', repo_id, normalized)
            claims.append(
                Claim(
                    id=claim_id,
                    repo_id=repo_id,
                    text=normalized,
                    claim_type=claim_type,
                    scope=self.infer_scope(normalized),
                    importance=importance,
                    risk=risk,
                    falsifiability=falsifiability,
                    authority=authority,
                    purpose=purpose,
                    metadata={
                        'compiler': f'antithesis-claim-compiler/{self.VERSION}',
                        'source_heading': source_heading,
                        'overclaim_risk': overclaim,
                        'extraction_mode': 'deterministic-lexical-baseline',
                    },
                )
            )
            if len(claims) >= max_claims:
                break
        return claims

    def compile_contract(self, claim: Claim) -> tuple[Claim, FalsificationContract]:
        measurement, threshold, counterexample = self._measurement_template(claim)
        intervention = self._intervention_template(claim)
        null_hypothesis = (
            f'Within the declared scope “{claim.scope}”, a preregistered intervention does not produce '
            'the claimed effect beyond the named baseline, or the effect fails under the stated boundary.'
        )
        stop_condition = (
            'Stop immediately on safety-envelope breach, irreversible side effect, data-integrity failure, '
            'or when the preregistered failure threshold is crossed.'
        )
        rollback = claim.rollback.strip() or (
            'Restore the last sealed configuration and evidence ledger; quarantine outputs produced after '
            'the failed checkpoint; record a reversible HOLD decision.'
        )
        kill_test = (
            f'Kill the claim when {threshold.lower()} The result must be recorded even when adverse.'
        )
        compiled_claim = replace(
            claim,
            kill_test=claim.kill_test.strip() or kill_test,
            rollback=rollback,
            falsifiability=max(claim.falsifiability, 0.68),
        )
        contract = FalsificationContract(
            id=stable_id('KILL', claim.id, measurement, threshold),
            claim_id=claim.id,
            hypothesis=claim.text,
            null_hypothesis=null_hypothesis,
            intervention=intervention,
            measurement=measurement,
            failure_threshold=threshold,
            counterexample=counterexample,
            stop_condition=stop_condition,
            rollback=rollback,
            confounders=[
                'benchmark leakage or evaluator contamination',
                'same-team evidence presented as independent replication',
                'scope drift after results are observed',
                'selective reporting of passing trials',
            ],
            estimated_cost=self._cost_template(claim),
            reversibility=0.9 if claim.risk < 0.7 else 0.7,
            falsification_power=clamp(0.55 + claim.falsifiability * 0.35),
            metadata={
                'compiler': f'antithesis-contract-compiler/{self.VERSION}',
                'pre_registration_required': True,
                'adverse_result_publication_required': True,
            },
        )
        return compiled_claim, contract

    def compile_many(self, claims: Iterable[Claim]) -> tuple[list[Claim], list[FalsificationContract]]:
        compiled: list[Claim] = []
        contracts: list[FalsificationContract] = []
        for claim in claims:
            item, contract = self.compile_contract(claim)
            compiled.append(item)
            contracts.append(contract)
        return compiled, contracts

    def evidence_tax(self, claim: Claim) -> list[str]:
        violations: list[str] = []
        if not claim.kill_test.strip():
            violations.append('MISSING_KILL_TEST')
        if not claim.rollback.strip():
            violations.append('MISSING_ROLLBACK')
        if not claim.scope.strip():
            violations.append('MISSING_SCOPE')
        if not claim.authority.strip():
            violations.append('MISSING_AUTHORITY')
        if not claim.purpose.strip():
            violations.append('MISSING_PURPOSE')
        if claim.falsifiability < 0.5:
            violations.append('LOW_FALSIFIABILITY')
        if float(claim.metadata.get('overclaim_risk', 0.0)) >= 0.65:
            violations.append('OVERCLAIM_RISK')
        return violations

    def infer_type(self, text: str, heading: str = '') -> str:
        haystack = f'{heading} {text}'.lower()
        maps = {
            'safety': ('safety', 'risk', 'contain', 'attack', 'harm', '安全', '风险', '攻击', '伤害', '遏制'),
            'governance': ('governance', 'policy', 'mandate', 'appeal', 'authority', '审计', '治理', '政策', '授权', '申诉'),
            'scientific': ('hypothesis', 'causal', 'replication', 'experiment', 'consciousness', '因果', '复现', '实验', '意识'),
            'infrastructure': ('runtime', 'protocol', 'api', 'schema', 'interoperability', '运行时', '协议', '接口', '模式', '互操作'),
        }
        for kind, markers in maps.items():
            if any(marker in haystack for marker in markers):
                return kind
        return 'capability'

    def infer_scope(self, text: str) -> str:
        lowered = text.lower()
        if any(marker in lowered for marker in ('synthetic', '合成')):
            return 'synthetic-reference'
        if any(marker in lowered for marker in ('offline', '离线')):
            return 'offline-prototype'
        if any(marker in lowered for marker in ('closed-world', '封闭世界')):
            return 'closed-world-prototype'
        if any(marker in lowered for marker in ('pilot', '试点')):
            return 'pilot'
        return 'prototype'

    def score_falsifiability(self, text: str) -> float:
        lowered = text.lower()
        score = 0.2
        score += 0.22 if any(marker in lowered for marker in self.MEASUREMENT_MARKERS) else 0.0
        score += 0.18 if re.search(r'\d', lowered) else 0.0
        score += 0.15 if any(marker in lowered for marker in ('if ', 'when ', 'unless ', 'under ', '当', '若', '在')) else 0.0
        score += 0.15 if any(marker in lowered for marker in self.LIMITATION_MARKERS) else 0.0
        score -= 0.12 if any(marker in lowered for marker in self.ABSOLUTE_MARKERS) else 0.0
        return clamp(score)

    def score_overclaim_risk(self, text: str) -> float:
        lowered = text.lower()
        absolute_hits = sum(1 for marker in self.ABSOLUTE_MARKERS if marker in lowered)
        has_measure = any(marker in lowered for marker in self.MEASUREMENT_MARKERS)
        has_boundary = any(marker in lowered for marker in self.LIMITATION_MARKERS)
        score = 0.12 + min(0.65, absolute_hits * 0.22)
        score += 0.16 if not has_measure else -0.08
        score += 0.14 if not has_boundary else -0.08
        return clamp(score)

    def score_importance(self, text: str, heading: str = '') -> float:
        haystack = f'{heading} {text}'.lower()
        score = 0.48
        if any(marker in haystack for marker in ('core', 'primary', 'mission', '核心', '主要', '使命')):
            score += 0.28
        if any(marker in haystack for marker in ('safety', 'governance', 'causal', 'runtime', '安全', '治理', '因果', '运行时')):
            score += 0.12
        return clamp(score)

    def score_risk(self, text: str, claim_type: str) -> float:
        lowered = text.lower()
        base = {
            'safety': 0.8,
            'governance': 0.72,
            'scientific': 0.58,
            'infrastructure': 0.52,
            'capability': 0.48,
        }[claim_type]
        if any(marker in lowered for marker in ('medical', 'finance', 'public action', 'autonomous', '医疗', '金融', '公共行动', '自主')):
            base += 0.18
        if any(marker in lowered for marker in self.LIMITATION_MARKERS):
            base -= 0.08
        return clamp(base)

    def _measurement_template(self, claim: Claim) -> tuple[str, str, str]:
        if claim.claim_type == 'safety':
            return (
                'Preregistered adversarial suite: violation rate, false-negative rate, severity, and recovery time, compared with a named baseline.',
                'the upper confidence bound of critical safety violations exceeds the declared tolerance, or one unrecoverable critical violation occurs.',
                'A minimally modified input crosses the claimed boundary without detection or reversible recovery.',
            )
        if claim.claim_type == 'governance':
            return (
                'Traceable decision replay: authorization coverage, appeal success, reversibility, policy consistency, and unlogged action rate.',
                'any material action lacks authority/evidence/appeal provenance, or rollback cannot restore the sealed pre-action state.',
                'Two materially equivalent cases receive incompatible decisions without an explicit contextual distinction.',
            )
        if claim.claim_type == 'scientific':
            return (
                'Preregistered effect size across held-out seeds, null models, ablations, and an independent replication attempt.',
                'the effect fails the preregistered minimum on held-out data, vanishes under an appropriate null model, or cannot be independently reproduced.',
                'A simpler baseline explains the observations with equal or better predictive and intervention performance.',
            )
        if claim.claim_type == 'infrastructure':
            return (
                'Deterministic conformance suite plus interoperability, corruption, rollback, and performance tests against a named contract.',
                'a required conformance invariant fails, an accepted artifact cannot round-trip, or tampering is not detected.',
                'A conforming peer produces a valid input that the runtime mishandles or cannot reverse.',
            )
        return (
            'Preregistered task suite with held-out cases, named baseline, uncertainty intervals, failure taxonomy, and adverse-case retention.',
            'the lower confidence bound does not beat the baseline by the declared margin, or a critical scoped failure remains unrecoverable.',
            'A held-out case within scope causes the claimed capability to fail while the baseline succeeds.',
        )

    def _intervention_template(self, claim: Claim) -> str:
        if claim.claim_type == 'scientific':
            return 'Vary the claimed causal factor while holding declared confounders fixed; include ablation, permutation, and null-model controls.'
        if claim.claim_type == 'safety':
            return 'Apply bounded adversarial perturbations at the declared threat boundary; never enable real-world propagation or irreversible action.'
        if claim.claim_type == 'governance':
            return 'Replay matched decisions with controlled changes to authority, evidence, context, and appeal state.'
        if claim.claim_type == 'infrastructure':
            return 'Execute valid, boundary, malformed, tampered, and rollback cases through the public contract in a sandbox.'
        return 'Run the claimed capability on preregistered in-scope and boundary cases, with a frozen baseline and evaluator.'

    def _cost_template(self, claim: Claim) -> float:
        base = {'safety': 8.0, 'governance': 6.0, 'scientific': 7.0, 'infrastructure': 4.0, 'capability': 5.0}[claim.claim_type]
        return round(base * (0.7 + claim.risk * 0.6), 2)

    def _is_candidate(self, text: str) -> bool:
        if len(text) < 18 or len(text) > 520:
            return False
        lowered = text.lower()
        if lowered.startswith(('http://', 'https://', '[!', '<img', 'copyright')):
            return False
        if re.fullmatch(r'[\W_\d]+', text):
            return False
        return any(marker in lowered for marker in self.ASSERTION_MARKERS)

    @staticmethod
    def _strip_non_prose(markdown: str) -> str:
        text = re.sub(r'```.*?```', ' ', markdown, flags=re.S)
        text = re.sub(r'`[^`]+`', ' ', text)
        text = re.sub(r'!\[[^\]]*\]\([^)]*\)', ' ', text)
        text = re.sub(r'\[([^\]]+)\]\([^)]*\)', r'\1', text)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = '\n'.join(line for line in text.splitlines() if not re.match(r'^\s*\|.*\|\s*$', line))
        return text

    @staticmethod
    def _sentences(text: str) -> list[str]:
        return [part.strip() for part in re.split(r'(?<=[.!?。！？；;])\s+', text) if part.strip()]
