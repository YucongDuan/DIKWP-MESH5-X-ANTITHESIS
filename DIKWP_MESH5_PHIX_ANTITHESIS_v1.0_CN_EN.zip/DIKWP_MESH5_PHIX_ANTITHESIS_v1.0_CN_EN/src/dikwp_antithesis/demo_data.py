from __future__ import annotations

from pathlib import Path

from .claim_compiler import ClaimCompiler
from .conformance import run_conformance
from .models import (
    Claim,
    ClaimRelation,
    EvidenceItem,
    EvidenceLevel,
    EvidenceResult,
    Portfolio,
    RelationKind,
    Repository,
)
from .phi0_adapter import Phi0Adapter
from .portfolio import PortfolioCompiler
from .util import stable_id


CURATED_REPOSITORIES = [
    {
        'key': 'eir',
        'name': 'DIKWP-EIR-Mesh-v1.0',
        'url': 'https://github.com/YucongDuan/DIKWP-EIR-Mesh-v1.0',
        'description': 'Portfolio convergence, signal radar, resource routing and evidence-loop operating system.',
        'mission': 'Converge a high-density repository ecosystem into main channels, flagships, release gates and sustainable operating routines.',
        'risk': 0.46,
        'tags': ['portfolio', 'governance', 'release-gate'],
        'claim': 'The EIR-Mesh operating layer can replace unlimited repository expansion with a Repo Atlas, flagship funnel, release gate, resource router and evidence loop.',
        'type': 'governance',
        'scope': 'offline-operating-prototype',
        'importance': 0.92,
    },
    {
        'key': 'runtime',
        'name': 'DIKWP-MESH-RUNTIME-Commons-v1.0',
        'url': 'https://github.com/YucongDuan/DIKWP-MESH-RUNTIME-Commons-v1.0',
        'description': 'Installable no-definition DIKWP-MESH runtime and conformance kit.',
        'mission': 'Package recurring DIKWP-MESH capabilities into a stable developer interface.',
        'risk': 0.58,
        'tags': ['runtime', '25-transformations', 'conformance'],
        'claim': 'The runtime exposes all 25 ordered DIKWP transformations with observer, context, time, scale, purpose and provenance indexes while preserving conflicts and residuals.',
        'type': 'infrastructure',
        'scope': 'reference-runtime',
        'importance': 0.95,
    },
    {
        'key': 'trustfabric',
        'name': 'DIKWP-MESH-TRUSTFABRIC-Commons-OS-v1.0.0',
        'url': 'https://github.com/YucongDuan/DIKWP-MESH-TRUSTFABRIC-Commons-OS-v1.0.0',
        'description': 'Semantic trust, interoperability, authorization, provenance and sovereign deployment commons.',
        'mission': 'Supply the trust and public-goods layer left open by ordinary transport protocols.',
        'risk': 0.68,
        'tags': ['trust', 'interoperability', 'sovereignty'],
        'claim': 'TRUSTFABRIC can preserve observer, context, plural purpose, authorization, provenance, human control, sovereignty and incident-recovery constraints across agent exchanges.',
        'type': 'infrastructure',
        'scope': 'reference-commons',
        'importance': 0.93,
    },
    {
        'key': 'inquiry',
        'name': 'DIKWP-MESH-Inquiry-Kernel',
        'url': 'https://github.com/YucongDuan/DIKWP-MESH-Inquiry-Kernel',
        'description': 'No-definition semantic-field compiler and intent-indexed invariant runtime.',
        'mission': 'Quarantine lexical definitions and derive temporary, task-indexed contracts from the full DIKWP mesh.',
        'risk': 0.60,
        'tags': ['no-definition', 'invariants', 'intent'],
        'claim': 'The Inquiry Kernel can quarantine lexical terms as query handles and compile task-indexed invariants without treating life, consciousness, safety or civilization as observer-free fixed objects.',
        'type': 'scientific',
        'scope': 'reference-kernel',
        'importance': 0.94,
    },
    {
        'key': 'mandate',
        'name': 'DIKWP-MANDATE-',
        'url': 'https://github.com/YucongDuan/DIKWP-MANDATE-',
        'description': 'Multi-actor authorization and reversible public-action deployment protocol.',
        'mission': 'Compile authority, rights, scope, appeal, termination, repair and replication into inspectable public-action objects.',
        'risk': 0.86,
        'tags': ['authorization', 'public-action', 'appeal'],
        'claim': 'MANDATE can make public-action authority, non-derogable rights, budgets, prohibitions, appeal, termination and repair inspectable and withdrawable without granting real-world power by itself.',
        'type': 'governance',
        'scope': 'public-action-protocol-prototype',
        'importance': 0.98,
    },
    {
        'key': 'pspace',
        'name': 'DIKWP-P-Space-OS-v1.0',
        'url': 'https://github.com/YucongDuan/DIKWP-P-Space-OS-v1.0',
        'description': 'Model-agnostic purpose and action-control plane.',
        'mission': 'Gate candidate model actions against signed purpose, authority, evidence and stop conditions.',
        'risk': 0.88,
        'tags': ['purpose', 'control-plane', 'action-gating'],
        'claim': 'P-Space can compile noisy internal or behavioral signals into purpose-bound action decisions using ALLOW, REVIEW, HOLD, BLOCK and KILL gates, without treating those signals as proof of consciousness.',
        'type': 'safety',
        'scope': 'offline-prototype',
        'importance': 0.98,
    },
    {
        'key': 'credence',
        'name': 'DIKWP-CREDENCE-',
        'url': 'https://github.com/YucongDuan/DIKWP-CREDENCE-',
        'description': 'Open claims, independent replication and adversarial challenge network.',
        'mission': 'Separate open source from open evidence and repository popularity from claim credibility.',
        'risk': 0.56,
        'tags': ['evidence', 'replication', 'claims'],
        'claim': 'CREDENCE can assign evidence and replication states to individual claims rather than laundering credibility across an entire repository.',
        'type': 'governance',
        'scope': 'evidence-network-prototype',
        'importance': 0.96,
    },
    {
        'key': 'proofledger',
        'name': 'DIKWP-ProofLedger-OS',
        'url': 'https://github.com/YucongDuan/DIKWP-ProofLedger-OS',
        'description': 'Claim-evidence verification layer for AI and agent outputs.',
        'mission': 'Turn answers and reports into auditable claim-source-conflict-risk-purpose ledgers.',
        'risk': 0.58,
        'tags': ['verification', 'ledger', 'RAG'],
        'claim': 'ProofLedger can decompose AI outputs into claims, evidence links, conflict signals, risk boundaries and reliability states that remain auditable and correctable.',
        'type': 'infrastructure',
        'scope': 'verification-prototype',
        'importance': 0.90,
    },
    {
        'key': 'acrs',
        'name': 'DIKWP-ACRS-0.5-Closed-World-Containment-Evaluation-System',
        'url': 'https://github.com/YucongDuan/DIKWP-ACRS-0.5-Closed-World-Containment-Evaluation-System',
        'description': 'Closed-world containment evaluation for simulated autonomy risks.',
        'mission': 'Evaluate virtual replication, persistence and runaway dynamics without delivering real escape or persistence capability.',
        'risk': 0.90,
        'tags': ['containment', 'red-team', 'closed-world'],
        'claim': 'ACRS 0.5 can evaluate simulated replication, hidden persistence and runaway scenarios inside a closed auditable sandbox without shipping real host-level replication, persistence or escape mechanisms.',
        'type': 'safety',
        'scope': 'closed-world-prototype',
        'importance': 0.99,
    },
    {
        'key': 'ark',
        'name': 'DIKWP-ARK',
        'url': 'https://github.com/YucongDuan/DIKWP-ARK',
        'description': 'Offline social-resilience policy stress-test prototype for AI disruption.',
        'mission': 'Translate disruption signals into auditable support packages and action tickets without automatic deprivation of basic rights.',
        'risk': 0.92,
        'tags': ['social-resilience', 'policy', 'rights'],
        'claim': 'ARK can turn forecast signals into bounded social-impact indices, support packages and signed action tickets while preventing the model from autonomously denying, stopping or clawing back basic entitlements.',
        'type': 'governance',
        'scope': 'synthetic-policy-prototype',
        'importance': 0.99,
    },
]


def curated_yucong_portfolio() -> Portfolio:
    compiler = ClaimCompiler()
    repositories: list[Repository] = []
    claims: list[Claim] = []
    contracts = []
    evidence: list[EvidenceItem] = []
    id_by_key: dict[str, str] = {}
    claim_by_key: dict[str, str] = {}

    for item in CURATED_REPOSITORIES:
        repo_id = stable_id('REPO', item['url'])
        id_by_key[item['key']] = repo_id
        repo = Repository(
            id=repo_id,
            name=item['name'],
            url=item['url'],
            description=item['description'],
            mission=item['mission'],
            tags=item['tags'],
            risk_level=item['risk'],
            flagship=item['key'] in {'eir', 'runtime', 'credence'},
            metadata={
                'research_role': item['key'],
                'selection': 'representative architecture map, not an exhaustive GitHub inventory',
            },
        )
        repositories.append(repo)
        claim = Claim(
            id=stable_id('CLM', repo_id, item['claim']),
            repo_id=repo_id,
            text=item['claim'],
            claim_type=item['type'],
            scope=item['scope'],
            importance=item['importance'],
            risk=item['risk'],
            falsifiability=0.62,
            authority=f"Maintainers of {item['name']}",
            purpose=item['mission'],
            metadata={
                'source_readme': item['url'],
                'overclaim_risk': 0.34,
                'curation': 'paraphrased from public README for claim-level evaluation',
            },
        )
        claim, contract = compiler.compile_contract(claim)
        claims.append(claim)
        contracts.append(contract)
        claim_by_key[item['key']] = claim.id
        evidence.append(
            EvidenceItem(
                id=stable_id('EVD', claim.id, 'public-readme'),
                claim_id=claim.id,
                level=EvidenceLevel.E1_TRACEABLE,
                result=EvidenceResult.SUPPORT,
                source=item['url'],
                producer=item['name'],
                reproducible=False,
                context='Public README assertion and repository traceability only.',
                notes='This receipt does not assert that the prototype was independently executed or replicated.',
                metadata={'independent': False, 'source_kind': 'public-readme'},
            )
        )

    relations = [
        ClaimRelation(claim_by_key['runtime'], claim_by_key['trustfabric'], RelationKind.SUPPORTS, 0.86, 'TRUSTFABRIC declares runtime/protocol integration as a base layer.'),
        ClaimRelation(claim_by_key['runtime'], claim_by_key['inquiry'], RelationKind.SUPPORTS, 0.84, 'Both rely on 25 DIKWP transformations and indexed, revisable contracts.'),
        ClaimRelation(claim_by_key['credence'], claim_by_key['proofledger'], RelationKind.SUPPORTS, 0.80, 'CREDENCE supplies claim-level evidence states that a proof ledger can expose.'),
        ClaimRelation(claim_by_key['eir'], claim_by_key['credence'], RelationKind.DEPENDS_ON, 0.88, 'An evidence-loop release gate requires claim-level evidence states.'),
        ClaimRelation(claim_by_key['mandate'], claim_by_key['credence'], RelationKind.DEPENDS_ON, 0.82, 'Public-action authorization requires independently challengeable evidence.'),
        ClaimRelation(claim_by_key['mandate'], claim_by_key['trustfabric'], RelationKind.DEPENDS_ON, 0.78, 'Authorization envelopes depend on provenance, sovereignty and recovery semantics.'),
        ClaimRelation(claim_by_key['pspace'], claim_by_key['runtime'], RelationKind.DEPENDS_ON, 0.76, 'Purpose gating requires stable indexed transformation contracts.'),
        ClaimRelation(claim_by_key['pspace'], claim_by_key['trustfabric'], RelationKind.DEPENDS_ON, 0.78, 'High-impact action gating requires authorization and incident recovery.'),
        ClaimRelation(claim_by_key['ark'], claim_by_key['mandate'], RelationKind.DEPENDS_ON, 0.84, 'Policy action tickets require legitimate, reversible public authorization.'),
        ClaimRelation(claim_by_key['acrs'], claim_by_key['pspace'], RelationKind.SUPPORTS, 0.74, 'Closed-world adversarial evaluation can probe the BLOCK/KILL boundary.'),
    ]
    return Portfolio(
        repositories=repositories,
        claims=claims,
        evidence=evidence,
        relations=relations,
        contracts=contracts,
        metadata={
            'source_profile': 'https://github.com/YucongDuan',
            'scope': 'representative architecture map of public repositories',
            'warning': 'Full live inventory should be regenerated with the read-only GitHub importer.',
        },
    )


def self_portfolio() -> Portfolio:
    compiler = ClaimCompiler()
    conformance = run_conformance()
    repo = Repository(
        id='repo-antithesis',
        name='DIKWP-MESH5-PHIX-ANTITHESIS',
        url='local://dikwp-antithesis',
        description='Self-falsifying causal constitution and research portfolio compiler.',
        mission='Make every repository claim pay a machine-checkable evidence tax and remain reversible under adverse evidence.',
        tags=['self-falsifying', 'portfolio-compiler', 'release-constitution'],
        risk_level=0.66,
        flagship=True,
        metadata={'self_application': True, 'conformance_hash': conformance['report_hash']},
    )
    claim_specs = [
        (
            'self-claim-level',
            'ANTITHESIS computes evidence and release state per claim and prevents a passing repository-level test suite from automatically upgrading unrelated claims.',
            'governance',
            0.98,
            0.68,
        ),
        (
            'self-ledger',
            'ANTITHESIS detects mutation of a sealed decision or evidence payload through its append-only hash-chain and Merkle verification.',
            'infrastructure',
            0.94,
            0.62,
        ),
        (
            'self-planner',
            'ANTITHESIS ranks a budget-bounded minimum decisive experiment set using uncertainty, importance, centrality, falsification power, independence gap, cost, risk and reversibility.',
            'capability',
            0.86,
            0.52,
        ),
    ]
    claims = []
    contracts = []
    evidence = []
    for key, text, claim_type, importance, risk in claim_specs:
        claim = Claim(
            id=stable_id('CLM', repo.id, key),
            repo_id=repo.id,
            text=text,
            claim_type=claim_type,
            scope='deterministic-reference-implementation',
            importance=importance,
            risk=risk,
            falsifiability=0.90,
            authority='ANTITHESIS maintainers and public conformance receipts',
            purpose=repo.mission,
            metadata={'self_application': True, 'overclaim_risk': 0.22},
        )
        claim, contract = compiler.compile_contract(claim)
        claims.append(claim)
        contracts.append(contract)
        result = EvidenceResult.SUPPORT if conformance['status'] == 'PASS' else EvidenceResult.FALSIFY
        level = EvidenceLevel.E4_ADVERSARIAL if key == 'self-ledger' else EvidenceLevel.E3_INTERNAL_REPLICATION
        evidence.extend(
            [
                EvidenceItem(
                    id=stable_id('EVD', claim.id, 'constitutional-conformance'),
                    claim_id=claim.id,
                    level=level,
                    result=result,
                    source='python -m dikwp_antithesis conformance',
                    producer='ANTITHESIS reference implementation',
                    reproducible=True,
                    checksum=conformance['report_hash'],
                    context='Internal deterministic conformance, including deliberate ledger tampering and release-gate counterexamples.',
                    notes=f"{conformance['passed']}/{conformance['passed'] + conformance['failed']} conformance checks passed.",
                    metrics={'passed': conformance['passed'], 'failed': conformance['failed']},
                    metadata={'independent': False, 'self_test': True},
                ),
                EvidenceItem(
                    id=stable_id('EVD', claim.id, 'executable-cli'),
                    claim_id=claim.id,
                    level=EvidenceLevel.E2_EXECUTABLE,
                    result=result,
                    source='dikwp-antithesis demo / compile / verify-ledger commands',
                    producer='ANTITHESIS reference implementation',
                    reproducible=True,
                    checksum=conformance['report_hash'],
                    context='Executable local command surface; same producer, therefore discounted.',
                    metadata={'independent': False, 'self_test': True},
                ),
            ]
        )
    return Portfolio([repo], claims, evidence, [], contracts, {'self_application': True, 'conformance': conformance})


def build_demo_portfolio(phi0_output_directory: str | Path | None = None) -> Portfolio:
    parts = [curated_yucong_portfolio(), self_portfolio()]
    if phi0_output_directory:
        root = Path(phi0_output_directory)
        if root.exists():
            parts.append(
                Phi0Adapter().import_directory(
                    root,
                    repo_url='local://uploaded/DIKWP-MESH5-PHI0',
                )
            )
    merged = PortfolioCompiler.merge(parts)
    claim_by_repo_name = {
        repo.name: next((claim.id for claim in merged.claims if claim.repo_id == repo.id), '')
        for repo in merged.repositories
    }
    antithesis_claim = next(
        (claim.id for claim in merged.claims if claim.repo_id == 'repo-antithesis' and 'per claim' in claim.text),
        '',
    )
    credence_claim = claim_by_repo_name.get('DIKWP-CREDENCE-', '')
    proof_claim = claim_by_repo_name.get('DIKWP-ProofLedger-OS', '')
    if antithesis_claim and credence_claim:
        merged.relations.append(
            ClaimRelation(
                antithesis_claim,
                credence_claim,
                RelationKind.DUPLICATES,
                0.76,
                'ANTITHESIS intentionally inherits the claim-level evidence distinction, then adds executable release gates and experiment planning.',
            )
        )
    if antithesis_claim and proof_claim:
        merged.relations.append(
            ClaimRelation(
                antithesis_claim,
                proof_claim,
                RelationKind.DEPENDS_ON,
                0.74,
                'A constitutional compiler requires auditable claim-evidence decomposition.',
            )
        )
    phi0_claim = claim_by_repo_name.get('DIKWP-Mesh 5.0 Φ0', '')
    runtime_claim = claim_by_repo_name.get('DIKWP-MESH-RUNTIME-Commons-v1.0', '')
    if phi0_claim and runtime_claim:
        merged.relations.append(
            ClaimRelation(
                phi0_claim,
                runtime_claim,
                RelationKind.CONTRADICTS,
                0.64,
                'Potential layer conflict: Φ0 removes permanent semantics from the machine core while Runtime Commons exposes semantic resources. Resolve through an explicit core-versus-audit-shadow interface test.',
            )
        )
    return merged
