from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .claim_compiler import ClaimCompiler
from .constitution import ConstitutionPolicy, ReleaseConstitution
from .evidence import EvidenceEngine
from .graph import ClaimGraph
from .ledger import HashLedger
from .models import (
    Claim,
    DecisionState,
    FalsificationContract,
    Portfolio,
    to_dict,
)
from .planner import ExperimentPlanner
from .util import sha256_json, utc_now, write_json


class PortfolioCompiler:
    """Compile a repository ecosystem into claim-level constitutional decisions."""

    SYSTEM = 'DIKWP-MESH5 ΦX / ANTITHESIS'
    VERSION = '1.0.0'

    def __init__(
        self,
        *,
        policy: ConstitutionPolicy | None = None,
        evidence_prior: float = 0.35,
    ) -> None:
        self.claim_compiler = ClaimCompiler()
        self.evidence_engine = EvidenceEngine(prior=evidence_prior)
        self.constitution = ReleaseConstitution(policy)
        self.planner = ExperimentPlanner()

    @staticmethod
    def merge(portfolios: Iterable[Portfolio]) -> Portfolio:
        repositories = {}
        claims = {}
        evidence = {}
        relations = {}
        contracts = {}
        metadata_sources = []
        for portfolio in portfolios:
            repositories.update({item.id: item for item in portfolio.repositories})
            claims.update({item.id: item for item in portfolio.claims})
            evidence.update({item.id: item for item in portfolio.evidence})
            relations.update(
                {
                    (item.source_claim_id, item.target_claim_id, item.kind.value): item
                    for item in portfolio.relations
                }
            )
            contracts.update({item.claim_id: item for item in portfolio.contracts})
            metadata_sources.append(portfolio.metadata)
        return Portfolio(
            repositories=list(repositories.values()),
            claims=list(claims.values()),
            evidence=list(evidence.values()),
            relations=list(relations.values()),
            contracts=list(contracts.values()),
            metadata={'merged_sources': metadata_sources},
        )

    def compile(
        self,
        portfolio: Portfolio,
        *,
        budget: float = 60.0,
        max_experiments: int = 12,
        as_of: datetime | None = None,
        ledger: HashLedger | None = None,
    ) -> dict:
        current = as_of or datetime.now(timezone.utc)
        timestamp = current.replace(microsecond=0).isoformat().replace('+00:00', 'Z')
        normalized = self._ensure_contracts(portfolio)
        graph = ClaimGraph(normalized.claims, normalized.relations)
        inferred = graph.infer_relations()
        assessments = self.evidence_engine.assess_all(normalized.claims, normalized.evidence)
        diagnostics = graph.diagnostics(assessments)
        decisions = self.constitution.evaluate_all(
            normalized.repositories,
            normalized.claims,
            assessments,
            graph,
            as_of=current,
        )
        plans = self.planner.plan(normalized.claims, normalized.contracts, assessments, graph)
        decisive_set = self.planner.minimum_decisive_set(
            plans,
            graph,
            budget=budget,
            max_experiments=max_experiments,
        )
        tax = {
            claim.id: self.claim_compiler.evidence_tax(claim)
            for claim in normalized.claims
            if self.claim_compiler.evidence_tax(claim)
        }
        report = {
            'system': self.SYSTEM,
            'version': self.VERSION,
            'generated_at': timestamp,
            'constitutional_laws': self.constitution.policy.laws,
            'scope_note': (
                'This report governs evidence and release claims. It does not prove consciousness, universal semantics, '
                'safety, or real-world validity merely by compiling a repository.'
            ),
            'portfolio_hash': sha256_json(normalized.to_dict()),
            'summary': self._summary(normalized, assessments, decisions, diagnostics, tax, decisive_set, budget, len(graph.relations)),
            'repositories': [to_dict(item) for item in normalized.repositories],
            'claims': [
                {
                    **to_dict(claim),
                    'assessment': to_dict(assessments[claim.id]),
                    'evidence_tax': tax.get(claim.id, []),
                }
                for claim in normalized.claims
            ],
            'evidence': [to_dict(item) for item in normalized.evidence],
            'relations': [to_dict(item) for item in graph.relations],
            'graph_diagnostics': diagnostics.to_dict(),
            'contracts': [to_dict(item) for item in normalized.contracts],
            'decisions': [to_dict(item) for item in decisions],
            'experiment_queue': [to_dict(item) for item in plans],
            'minimum_decisive_set': [to_dict(item) for item in decisive_set],
            'policy': to_dict(self.constitution.policy),
            'compiler_notes': {
                'inferred_relations_added': len(inferred),
                'lexical_graph_is_baseline': True,
                'evidence_independence_is_discounted': True,
                'promotions_are_time_bounded': True,
                'adverse_results_must_be_retained': True,
            },
        }
        active_ledger = ledger or HashLedger()
        active_ledger.append('PORTFOLIO_INPUT_SEALED', {'portfolio_hash': report['portfolio_hash']}, timestamp=timestamp)
        active_ledger.append('CLAIM_ASSESSMENTS_COMPILED', {key: to_dict(value) for key, value in assessments.items()}, timestamp=timestamp)
        active_ledger.append('GRAPH_DIAGNOSTICS_COMPILED', report['graph_diagnostics'], timestamp=timestamp)
        active_ledger.append('RELEASE_DECISIONS_ISSUED', report['decisions'], timestamp=timestamp)
        active_ledger.append('MINIMUM_DECISIVE_SET_ISSUED', report['minimum_decisive_set'], timestamp=timestamp)
        active_ledger.append('REPORT_SEALED', {'report_hash': sha256_json(report)}, timestamp=timestamp)
        report['ledger_verification'] = active_ledger.verify()
        report['_ledger'] = active_ledger
        return report

    def write_outputs(self, report: dict, output_directory: str | Path) -> dict[str, str]:
        output = Path(output_directory)
        output.mkdir(parents=True, exist_ok=True)
        serializable = {key: value for key, value in report.items() if key != '_ledger'}
        write_json(output / 'portfolio_report.json', serializable)
        write_json(output / 'decisions.json', report['decisions'])
        write_json(output / 'experiment_queue.json', report['experiment_queue'])
        write_json(output / 'minimum_decisive_set.json', report['minimum_decisive_set'])
        write_json(
            output / 'claim_graph.json',
            {
                'relations': report['relations'],
                'diagnostics': report['graph_diagnostics'],
            },
        )
        ledger: HashLedger = report['_ledger']
        ledger.write(output / 'ledger.jsonl')
        verification = ledger.verify()
        write_json(output / 'ledger_verification.json', verification)
        brief = self.executive_brief_cn(report)
        (output / 'EXECUTIVE_BRIEF_CN.md').write_text(brief, encoding='utf-8')
        return {
            'report': str(output / 'portfolio_report.json'),
            'decisions': str(output / 'decisions.json'),
            'experiment_queue': str(output / 'experiment_queue.json'),
            'minimum_decisive_set': str(output / 'minimum_decisive_set.json'),
            'graph': str(output / 'claim_graph.json'),
            'ledger': str(output / 'ledger.jsonl'),
            'ledger_verification': str(output / 'ledger_verification.json'),
            'brief_cn': str(output / 'EXECUTIVE_BRIEF_CN.md'),
        }

    def executive_brief_cn(self, report: dict) -> str:
        summary = report['summary']
        decision_counts = summary['decision_counts']
        lines = [
            '# ANTITHESIS 执行摘要',
            '',
            f"生成时间：{report['generated_at']}",
            '',
            '## 宪法性结论',
            '',
            '本系统不把“仓库存在、README 完整、自测通过”视为科学成立。证据状态逐主张计算；同一团队产生的多份成功记录会被折扣；没有独立复现就不能进入 PROMOTE。',
            '',
            f"- 仓库：{summary['repository_count']}；主张：{summary['claim_count']}；证据记录：{summary['evidence_count']}。",
            f"- 决策分布：{', '.join(f'{key}={value}' for key, value in decision_counts.items())}。",
            f"- 证伪债务指数：{summary['falsification_debt_index']:.3f}。",
            f"- 未解决冲突：{summary['unresolved_contradictions']}；疑似重复簇：{summary['duplicate_cluster_count']}。",
            f"- 当前没有证据自动升级：PROMOTE={decision_counts.get('PROMOTE', 0)}。",
            '',
            '## 最小决定性实验',
            '',
        ]
        for item in report['minimum_decisive_set'][:8]:
            target_ids = item.get('target_claim_ids') or [item['claim_id']]
            target_claims = [claim for claim in report['claims'] if claim['id'] in target_ids]
            target_repo_ids = list(dict.fromkeys(claim['repo_id'] for claim in target_claims))
            target_repos = [repo for repo in report['repositories'] if repo['id'] in target_repo_ids]
            title = ' ↔ '.join(repo['name'] for repo in target_repos)
            claim_text = '；'.join(claim['text'] for claim in target_claims)
            lines.extend(
                [
                    f"### {item['rank']}. {title}",
                    '',
                    f"主张：{claim_text}",
                    '',
                    f"实验类型：{item.get('experiment_type', 'claim-kill-test')}。",
                    '',
                    f"优先分：{item['score']}；预计信息增益：{item['expected_information_gain']}；成本单位：{item['estimated_cost']}。",
                    '',
                    f"干预：{item.get('intervention', '')}",
                    '',
                    f"测量：{item.get('measurement', '')}",
                    '',
                    f"失败阈值：{item.get('failure_threshold', '')}",
                    '',
                    f"解锁决策：{item['decision_unlocked']}",
                    '',
                ]
            )
        lines.extend(
            [
                '## 不可越过的边界',
                '',
                '1. 自测通过仍是内部证据；独立团队失败必须与成功同等公开。',
                '2. 任何主张若没有失败阈值、停止条件和回滚路径，发布状态只能是 HOLD。',
                '3. 仓库级“整体可信”被禁止；不同主张可同时处于 SUPPORTED、CONTESTED 和 FALSIFIED。',
                '4. 所有晋级自动到期，必须用新证据续期。',
                '',
                f"账本 Merkle 根：`{report['ledger_verification']['merkle_root']}`",
                '',
            ]
        )
        return '\n'.join(lines)

    def _ensure_contracts(self, portfolio: Portfolio) -> Portfolio:
        contract_by_claim = {contract.claim_id: contract for contract in portfolio.contracts}
        claims: list[Claim] = []
        contracts: list[FalsificationContract] = list(portfolio.contracts)
        for claim in portfolio.claims:
            if claim.id in contract_by_claim and claim.kill_test.strip() and claim.rollback.strip():
                claims.append(claim)
                continue
            compiled, contract = self.claim_compiler.compile_contract(claim)
            claims.append(compiled)
            if claim.id not in contract_by_claim:
                contracts.append(contract)
        return Portfolio(
            repositories=portfolio.repositories,
            claims=claims,
            evidence=portfolio.evidence,
            relations=portfolio.relations,
            contracts=contracts,
            metadata=portfolio.metadata,
        )

    @staticmethod
    def _summary(portfolio, assessments, decisions, diagnostics, tax, decisive_set, budget, relation_count) -> dict:
        evidence_levels = Counter(f'E{int(item.evidence_level)}' for item in assessments.values())
        statuses = Counter(item.status.value for item in assessments.values())
        decision_counts = Counter(item.state.value for item in decisions)
        for state in DecisionState:
            decision_counts.setdefault(state.value, 0)
        debt_numerator = 0.0
        debt_denominator = 0.0
        for claim in portfolio.claims:
            weight = max(0.05, claim.importance * (0.55 + 0.45 * claim.risk))
            assessment = assessments[claim.id]
            depth_gap = 1.0 - int(assessment.evidence_level) / 7.0
            independence_gap = 1.0 - assessment.independence_score
            debt_numerator += weight * (0.65 * depth_gap + 0.35 * independence_gap)
            debt_denominator += weight
        debt = debt_numerator / debt_denominator if debt_denominator else 0.0
        selected_cost = sum(item.estimated_cost for item in decisive_set)
        return {
            'repository_count': len(portfolio.repositories),
            'claim_count': len(portfolio.claims),
            'evidence_count': len(portfolio.evidence),
            'relation_count': relation_count,
            'evidence_level_counts': dict(sorted(evidence_levels.items())),
            'claim_status_counts': dict(sorted(statuses.items())),
            'decision_counts': dict(sorted(decision_counts.items())),
            'unresolved_contradictions': len(diagnostics.unresolved_contradictions),
            'duplicate_cluster_count': len(diagnostics.duplicate_clusters),
            'dependency_cycle_count': len(diagnostics.dependency_cycles),
            'evidence_tax_claims': len(tax),
            'falsification_debt_index': round(debt, 6),
            'minimum_decisive_experiments': len(decisive_set),
            'minimum_decisive_cost': round(selected_cost, 3),
            'budget': budget,
        }
