from __future__ import annotations

import json
from pathlib import Path

from .util import atomic_write_text


class DashboardGenerator:
    """Generate a self-contained offline constitutional dashboard."""

    def generate(self, report: dict, path: str | Path) -> Path:
        target = Path(path)
        payload = {key: value for key, value in report.items() if key != '_ledger'}
        encoded = json.dumps(payload, ensure_ascii=False).replace('</script', '<\\/script')
        html = self._template().replace('__ANTITHESIS_DATA__', encoded)
        atomic_write_text(target, html)
        return target

    @staticmethod
    def _template() -> str:
        return r'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DIKWP-MESH5 ΦX / ANTITHESIS</title>
<style>
:root{
  --bg:#081018;--panel:#0f1b27;--panel2:#132334;--ink:#edf4fb;--muted:#97a9bc;
  --line:#294056;--accent:#5eead4;--danger:#fb7185;--warn:#fbbf24;--ok:#86efac;
  --review:#93c5fd;--hold:#fda4af;--pilot:#c4b5fd;--promote:#6ee7b7;--retire:#f87171;
}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% -10%,#15304a 0,transparent 36%),var(--bg);color:var(--ink);font:14px/1.55 ui-sans-serif,system-ui,-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
a{color:var(--accent)}.shell{max-width:1440px;margin:auto;padding:28px}.hero{display:grid;grid-template-columns:1.5fr .5fr;gap:20px;align-items:end;margin-bottom:20px}.eyebrow{color:var(--accent);font-weight:750;letter-spacing:.14em;text-transform:uppercase}.hero h1{font-size:clamp(30px,4vw,56px);line-height:1;margin:.22em 0}.hero p{max-width:900px;color:var(--muted);font-size:16px}.seal{text-align:right;color:var(--muted);word-break:break-all}.lawbar{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:18px 0 24px}.law{background:rgba(15,27,39,.86);border:1px solid var(--line);border-radius:12px;padding:12px;color:#cfe0ef}.metrics{display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-bottom:24px}.metric,.panel{background:linear-gradient(160deg,rgba(19,35,52,.96),rgba(13,25,36,.96));border:1px solid var(--line);border-radius:16px;box-shadow:0 18px 45px rgba(0,0,0,.18)}.metric{padding:16px}.metric b{display:block;font-size:27px}.metric span{color:var(--muted)}.grid{display:grid;grid-template-columns:1.15fr .85fr;gap:16px}.panel{padding:18px;margin-bottom:16px;overflow:hidden}.panel h2{margin:0 0 12px;font-size:18px}.sub{color:var(--muted);font-size:13px}.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.toolbar input,.toolbar select{background:#09131d;color:var(--ink);border:1px solid var(--line);border-radius:9px;padding:9px 11px;min-width:150px}.scroll{overflow:auto;max-height:620px}table{border-collapse:collapse;width:100%;min-width:740px}th,td{text-align:left;padding:10px 8px;border-bottom:1px solid rgba(41,64,86,.65);vertical-align:top}th{position:sticky;top:0;background:#132334;color:#bcd0e2;z-index:1}.badge{display:inline-flex;align-items:center;border:1px solid currentColor;border-radius:999px;padding:2px 8px;font-weight:750;font-size:11px;letter-spacing:.04em}.PROMOTE{color:var(--promote)}.PILOT{color:var(--pilot)}.REVIEW{color:var(--review)}.HOLD{color:var(--hold)}.RETIRE{color:var(--retire)}.SUPPORTED{color:var(--ok)}.CONTESTED{color:var(--warn)}.FALSIFIED{color:var(--danger)}.UNTESTED{color:var(--muted)}.bar{height:8px;background:#07111a;border-radius:99px;overflow:hidden;min-width:110px;margin-top:5px}.bar i{height:100%;display:block;background:linear-gradient(90deg,#5eead4,#93c5fd)}.claim{padding:13px 0;border-bottom:1px solid rgba(41,64,86,.65)}.claim:last-child{border:0}.claim-head{display:flex;justify-content:space-between;gap:12px}.claim-text{font-weight:650}.meta{display:flex;gap:8px;flex-wrap:wrap;color:var(--muted);font-size:12px;margin-top:6px}.reason{color:#c7d7e5;margin-top:6px}.contract{margin-top:8px;border-left:2px solid var(--accent);padding-left:10px;color:#b9c9d8}.rank{font-size:24px;font-weight:850;color:var(--accent)}.queue-item{display:grid;grid-template-columns:52px 1fr auto;gap:12px;padding:14px 0;border-bottom:1px solid rgba(41,64,86,.65)}.queue-item:last-child{border:0}.score{font-weight:800}.callout{border:1px solid #5a4a1e;background:rgba(100,75,10,.18);padding:13px;border-radius:12px;color:#fde68a}.foot{color:var(--muted);text-align:center;padding:24px 0 8px}.empty{color:var(--muted);padding:22px;text-align:center}.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px}.decision-row{display:grid;grid-template-columns:1.1fr auto;gap:10px;padding:12px 0;border-bottom:1px solid rgba(41,64,86,.65)}.decision-row:last-child{border:0}.decision-row ul{margin:6px 0 0;padding-left:18px;color:var(--muted)}@media(max-width:1000px){.metrics{grid-template-columns:repeat(3,1fr)}.grid,.hero{grid-template-columns:1fr}.seal{text-align:left}.lawbar{grid-template-columns:1fr 1fr}}@media(max-width:620px){.shell{padding:16px}.metrics{grid-template-columns:1fr 1fr}.lawbar{grid-template-columns:1fr}.metric b{font-size:22px}}
</style>
</head>
<body><main class="shell">
<section class="hero"><div><div class="eyebrow">Self-falsifying research control plane</div><h1>ANTITHESIS</h1><p>DIKWP-MESH5 ΦX 自证伪因果宪法与科研生态编译系统。它不奖励仓库数量，而要求每个主张缴纳“证据税”：失败阈值、停止条件、回滚、独立复现与不利结果公开。</p></div><div class="seal"><div>Report hash</div><div id="portfolioHash" class="mono"></div><div style="margin-top:8px">Merkle root</div><div id="merkle" class="mono"></div></div></section>
<section id="laws" class="lawbar"></section>
<section id="metrics" class="metrics"></section>
<div class="grid">
  <div>
    <section class="panel"><h2>最小决定性实验 / Minimum decisive experiments</h2><div class="sub">在固定预算内最大化证伪信息，不最大化项目活动量。</div><div id="queue"></div></section>
    <section class="panel"><h2>主张浏览器 / Claim explorer</h2><div class="toolbar"><input id="search" placeholder="搜索主张、仓库…"><select id="status"><option value="">全部状态</option><option>UNTESTED</option><option>SUPPORTED</option><option>CONTESTED</option><option>FALSIFIED</option></select><select id="level"><option value="">全部证据层</option><option value="0">E0</option><option value="1">E1</option><option value="2">E2</option><option value="3">E3</option><option value="4">E4</option><option value="5">E5</option><option value="6">E6</option><option value="7">E7</option></select></div><div id="claims" class="scroll"></div></section>
  </div>
  <div>
    <section class="panel"><h2>发布宪法决策 / Release constitution</h2><div id="decisions"></div></section>
    <section class="panel"><h2>证据深度 / Evidence depth</h2><div id="evidenceTable" class="scroll"></div></section>
    <section class="panel"><h2>冲突与重复 / Contradictions & duplication</h2><div id="graphDiag"></div></section>
    <section class="panel"><h2>不可越过的边界</h2><div class="callout">10/10 自测通过仍不是独立复现。仓库级“整体可信”被禁止；同一仓库内不同主张可以同时被支持、争议或证伪。PROMOTE 自动到期，必须用新证据续期。</div></section>
  </div>
</div>
<div class="foot">Generated offline by DIKWP-MESH5 ΦX / ANTITHESIS · no external scripts · reversible decisions only</div>
</main>
<script id="antithesis-data" type="application/json">__ANTITHESIS_DATA__</script>
<script>
const R=JSON.parse(document.getElementById('antithesis-data').textContent);const $=s=>document.querySelector(s);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const repoMap=Object.fromEntries(R.repositories.map(x=>[x.id,x]));const contractMap=Object.fromEntries(R.contracts.map(x=>[x.claim_id,x]));
$('#portfolioHash').textContent=R.portfolio_hash;$('#merkle').textContent=R.ledger_verification.merkle_root;
$('#laws').innerHTML=R.constitutional_laws.map((x,i)=>`<div class="law"><b>${i+1}.</b> ${esc(x)}</div>`).join('');
const S=R.summary;const metricData=[['仓库',S.repository_count],['主张',S.claim_count],['证据',S.evidence_count],['证伪债务',S.falsification_debt_index],['未解冲突',S.unresolved_contradictions],['决定实验',S.minimum_decisive_experiments]];$('#metrics').innerHTML=metricData.map(x=>`<div class="metric"><b>${esc(x[1])}</b><span>${esc(x[0])}</span></div>`).join('');
$('#queue').innerHTML=R.minimum_decisive_set.length?R.minimum_decisive_set.map(p=>{const ids=p.target_claim_ids?.length?p.target_claim_ids:[p.claim_id],cs=ids.map(id=>R.claims.find(x=>x.id===id)).filter(Boolean),names=[...new Set(cs.map(c=>repoMap[c.repo_id]?.name).filter(Boolean))],title=names.join(' ↔ '),text=cs.map(c=>c.text).join(' ↔ ');return `<div class="queue-item"><div class="rank">${p.rank}</div><div><b>${esc(title)}</b><div>${esc(text)}</div><div class="meta"><span>${esc(p.experiment_type||'claim-kill-test')}</span> · ${p.priority_reasons.map(esc).join(' · ')}</div><details class="contract"><summary>实验合同</summary><div><b>干预：</b>${esc(p.intervention)}</div><div><b>测量：</b>${esc(p.measurement)}</div><div><b>失败阈值：</b>${esc(p.failure_threshold)}</div><div><b>回滚：</b>${esc(p.rollback)}</div></details><div class="contract"><b>解锁：</b>${esc(p.decision_unlocked)}</div></div><div><div class="score">${p.score}</div><div class="sub">cost ${p.estimated_cost}</div></div></div>`}).join(''):'<div class="empty">No experiments selected.</div>';
$('#decisions').innerHTML=R.decisions.map(d=>{const q=repoMap[d.repo_id];return `<div class="decision-row"><div><b>${esc(q?.name)}</b><div class="sub">${esc(d.reason_codes.join(' · '))}</div><ul>${d.conditions.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div><div><span class="badge ${d.state}">${d.state}</span><div class="sub" style="margin-top:7px">Emin ${d.metrics.minimum_core_evidence_level??'-'}</div></div></div>`}).join('');
function renderClaims(){const term=$('#search').value.toLowerCase(),status=$('#status').value,level=$('#level').value;const rows=R.claims.filter(c=>{const repo=repoMap[c.repo_id];return(!term||(c.text+' '+(repo?.name||'')).toLowerCase().includes(term))&&(!status||c.assessment.status===status)&&(!level||String(c.assessment.evidence_level)===level)});$('#claims').innerHTML=rows.length?rows.map(c=>{const a=c.assessment,q=repoMap[c.repo_id],k=contractMap[c.id];return `<article class="claim"><div class="claim-head"><div class="claim-text">${esc(c.text)}</div><span class="badge ${a.status}">${a.status}</span></div><div class="meta"><b>${esc(q?.name)}</b><span>E${a.evidence_level}</span><span>credence ${a.credence}</span><span>independence ${a.independence_score}</span><span>scope ${esc(c.scope)}</span></div><div class="bar"><i style="width:${Math.round(a.credence*100)}%"></i></div><div class="reason">${esc(a.rationale.join(' '))}</div>${k?`<details class="contract"><summary>证伪合同</summary><div><b>失败阈值：</b>${esc(k.failure_threshold)}</div><div><b>反例：</b>${esc(k.counterexample)}</div><div><b>回滚：</b>${esc(k.rollback)}</div></details>`:''}</article>`}).join(''):'<div class="empty">没有匹配主张。</div>'}['search','status','level'].forEach(id=>$('#'+id).addEventListener('input',renderClaims));renderClaims();
const levels=Object.entries(S.evidence_level_counts);$('#evidenceTable').innerHTML=`<table><thead><tr><th>层级</th><th>主张数</th><th>含义</th></tr></thead><tbody>${levels.map(([k,v])=>`<tr><td><b>${k}</b></td><td>${v}</td><td>${esc({E0:'断言',E1:'可追溯',E2:'可执行',E3:'内部复现',E4:'对抗检验',E5:'独立复现',E6:'跨情境',E7:'持续审计'}[k])}</td></tr>`).join('')}</tbody></table>`;
const G=R.graph_diagnostics;$('#graphDiag').innerHTML=`<div class="metric" style="margin:10px 0"><b>${G.unresolved_contradictions.length}</b><span>未解决冲突</span></div><div class="metric" style="margin:10px 0"><b>${G.duplicate_clusters.length}</b><span>疑似重复簇</span></div><div class="metric" style="margin:10px 0"><b>${G.dependency_cycles.length}</b><span>依赖闭环</span></div>${G.unresolved_contradictions.slice(0,4).map(r=>`<div class="contract">${esc(repoMap[R.claims.find(c=>c.id===r.source_claim_id)?.repo_id]?.name)} ↔ ${esc(repoMap[R.claims.find(c=>c.id===r.target_claim_id)?.repo_id]?.name)}<div class="sub">${esc(r.rationale)}</div></div>`).join('')}`;
</script>
</body></html>'''
