from __future__ import annotations

import hashlib
import hmac
import json
import os
from pathlib import Path
from typing import Any, Iterable

from .util import canonical_json, sha256_json, utc_now


class HashLedger:
    """Append-only hash-chain ledger with Merkle summary and optional HMAC seal."""

    GENESIS = '0' * 64

    def __init__(self, records: Iterable[dict[str, Any]] = (), path: str | Path | None = None) -> None:
        self.records = list(records)
        self.path = Path(path) if path else None

    @classmethod
    def load(cls, path: str | Path) -> 'HashLedger':
        target = Path(path)
        records: list[dict[str, Any]] = []
        if target.exists():
            with target.open('r', encoding='utf-8') as handle:
                for line_number, line in enumerate(handle, 1):
                    if not line.strip():
                        continue
                    try:
                        records.append(json.loads(line))
                    except json.JSONDecodeError as exc:
                        raise ValueError(f'Invalid ledger JSON at line {line_number}: {exc}') from exc
        return cls(records=records, path=target)

    def append(
        self,
        event_type: str,
        payload: Any,
        *,
        actor: str = 'antithesis',
        timestamp: str | None = None,
    ) -> dict[str, Any]:
        previous_hash = self.records[-1]['record_hash'] if self.records else self.GENESIS
        body = {
            'sequence': len(self.records),
            'timestamp': timestamp or utc_now(),
            'event_type': event_type,
            'actor': actor,
            'previous_hash': previous_hash,
            'payload_hash': sha256_json(payload),
            'payload': payload,
        }
        record_hash = hashlib.sha256(canonical_json(body).encode('utf-8')).hexdigest()
        record = {**body, 'record_hash': record_hash}
        self.records.append(record)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open('a', encoding='utf-8') as handle:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + '\n')
                handle.flush()
                os.fsync(handle.fileno())
        return record

    def verify(self) -> dict[str, Any]:
        errors: list[str] = []
        previous = self.GENESIS
        for expected_sequence, record in enumerate(self.records):
            if record.get('sequence') != expected_sequence:
                errors.append(f'sequence mismatch at record {expected_sequence}')
            if record.get('previous_hash') != previous:
                errors.append(f'previous_hash mismatch at record {expected_sequence}')
            payload_hash = sha256_json(record.get('payload'))
            if payload_hash != record.get('payload_hash'):
                errors.append(f'payload_hash mismatch at record {expected_sequence}')
            body = {key: value for key, value in record.items() if key != 'record_hash'}
            expected_hash = hashlib.sha256(canonical_json(body).encode('utf-8')).hexdigest()
            if expected_hash != record.get('record_hash'):
                errors.append(f'record_hash mismatch at record {expected_sequence}')
            previous = str(record.get('record_hash', ''))
        return {
            'status': 'PASS' if not errors else 'FAIL',
            'record_count': len(self.records),
            'tip_hash': self.records[-1]['record_hash'] if self.records else self.GENESIS,
            'merkle_root': self.merkle_root(),
            'errors': errors,
        }

    def merkle_root(self) -> str:
        hashes = [str(record.get('record_hash', '')) for record in self.records]
        if not hashes:
            return self.GENESIS
        layer = hashes
        while len(layer) > 1:
            if len(layer) % 2 == 1:
                layer = layer + [layer[-1]]
            next_layer: list[str] = []
            for index in range(0, len(layer), 2):
                combined = bytes.fromhex(layer[index]) + bytes.fromhex(layer[index + 1])
                next_layer.append(hashlib.sha256(combined).hexdigest())
            layer = next_layer
        return layer[0]

    def seal(self, key: bytes, *, signer: str = 'local-hmac') -> dict[str, str | int]:
        verification = self.verify()
        root = verification['merkle_root']
        signature = hmac.new(key, str(root).encode('utf-8'), hashlib.sha256).hexdigest()
        return {
            'algorithm': 'HMAC-SHA256',
            'signer': signer,
            'record_count': len(self.records),
            'merkle_root': str(root),
            'signature': signature,
        }

    @staticmethod
    def verify_seal(seal: dict[str, Any], key: bytes) -> bool:
        expected = hmac.new(key, str(seal['merkle_root']).encode('utf-8'), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, str(seal.get('signature', '')))

    def write(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('w', encoding='utf-8') as handle:
            for record in self.records:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + '\n')
