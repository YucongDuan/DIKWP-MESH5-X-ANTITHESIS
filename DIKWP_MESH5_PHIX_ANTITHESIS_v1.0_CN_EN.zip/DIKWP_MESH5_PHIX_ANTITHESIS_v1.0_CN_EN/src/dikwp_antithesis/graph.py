from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Iterable

from .models import Claim, ClaimAssessment, ClaimRelation, ClaimStatus, RelationKind, to_dict
from .util import clamp, jaccard, tokenize


@dataclass(slots=True)
class GraphDiagnostics:
    duplicate_clusters: list[list[str]]
    unresolved_contradictions: list[ClaimRelation]
    dependency_cycles: list[list[str]]
    centrality: dict[str, float]
    inferred_relation_count: int

    def to_dict(self) -> dict:
        return to_dict(self)


class ClaimGraph:
    """Transparent claim graph with replaceable lexical inference baselines."""

    NEGATION_MARKERS = (
        ' not ', ' no ', ' without ', ' cannot ', " can't ", ' never ', ' refuse ',
        '不', '无', '非', '未', '不能', '不会', '拒绝', '禁止',
    )
    ANTONYM_PAIRS = (
        ('centralized', 'decentralized'),
        ('semantic', 'asemantic'),
        ('persistent', 'disposable'),
        ('autonomous', 'human-controlled'),
        ('allow', 'block'),
        ('promote', 'retire'),
        ('集中式', '去中心化'),
        ('语义', '无语义'),
        ('持久', '一次性'),
        ('允许', '阻断'),
        ('晋级', '退役'),
    )

    def __init__(self, claims: Iterable[Claim], relations: Iterable[ClaimRelation] = ()) -> None:
        self.claims = {claim.id: claim for claim in claims}
        self.relations = list(relations)

    def infer_relations(
        self,
        *,
        duplicate_threshold: float = 0.72,
        contradiction_threshold: float = 0.46,
        cross_repo_only: bool = True,
    ) -> list[ClaimRelation]:
        known = {
            (relation.source_claim_id, relation.target_claim_id, relation.kind.value)
            for relation in self.relations
        }
        claims = list(self.claims.values())
        inferred: list[ClaimRelation] = []
        token_cache = {claim.id: tokenize(claim.text) for claim in claims}
        for index, left in enumerate(claims):
            for right in claims[index + 1 :]:
                if cross_repo_only and left.repo_id == right.repo_id:
                    continue
                similarity = jaccard(token_cache[left.id], token_cache[right.id])
                if similarity <= 0.0:
                    continue
                left_negated = self._is_negated(left.text)
                right_negated = self._is_negated(right.text)
                antonym = self._has_antonym_collision(left.text, right.text)
                if (left_negated != right_negated and similarity >= contradiction_threshold) or (
                    antonym and similarity >= contradiction_threshold * 0.72
                ):
                    relation = ClaimRelation(
                        source_claim_id=left.id,
                        target_claim_id=right.id,
                        kind=RelationKind.CONTRADICTS,
                        confidence=clamp(0.48 + similarity * 0.48),
                        rationale=(
                            f'Lexical baseline found shared content (Jaccard={similarity:.3f}) with '
                            'opposed polarity/antonym markers; human or causal review required.'
                        ),
                        inferred=True,
                    )
                    key = (relation.source_claim_id, relation.target_claim_id, relation.kind.value)
                    if key not in known:
                        inferred.append(relation)
                        known.add(key)
                    continue
                if left.claim_type == right.claim_type and left_negated == right_negated and similarity >= duplicate_threshold:
                    relation = ClaimRelation(
                        source_claim_id=left.id,
                        target_claim_id=right.id,
                        kind=RelationKind.DUPLICATES,
                        confidence=clamp(similarity),
                        rationale=(
                            f'Lexical baseline found high overlap (Jaccard={similarity:.3f}); '
                            'merge, differentiate, or register a scope distinction.'
                        ),
                        inferred=True,
                    )
                    key = (relation.source_claim_id, relation.target_claim_id, relation.kind.value)
                    if key not in known:
                        inferred.append(relation)
                        known.add(key)
        self.relations.extend(inferred)
        return inferred

    def centrality(self, iterations: int = 24, damping: float = 0.85) -> dict[str, float]:
        ids = list(self.claims)
        if not ids:
            return {}
        incoming: dict[str, list[tuple[str, float]]] = defaultdict(list)
        outgoing_weight: dict[str, float] = defaultdict(float)
        edge_weight = {
            RelationKind.SUPPORTS: 0.85,
            RelationKind.CONTRADICTS: 1.20,
            RelationKind.DUPLICATES: 0.45,
            RelationKind.DEPENDS_ON: 1.00,
        }
        for relation in self.relations:
            if relation.source_claim_id not in self.claims or relation.target_claim_id not in self.claims:
                continue
            weight = edge_weight[relation.kind] * relation.confidence
            incoming[relation.target_claim_id].append((relation.source_claim_id, weight))
            incoming[relation.source_claim_id].append((relation.target_claim_id, weight * 0.55))
            outgoing_weight[relation.source_claim_id] += weight
            outgoing_weight[relation.target_claim_id] += weight * 0.55
        n = len(ids)
        score = {claim_id: 1.0 / n for claim_id in ids}
        base = (1.0 - damping) / n
        for _ in range(iterations):
            next_score: dict[str, float] = {}
            for claim_id in ids:
                propagated = 0.0
                for source, weight in incoming.get(claim_id, []):
                    denominator = outgoing_weight.get(source, 0.0)
                    if denominator > 0:
                        propagated += score[source] * weight / denominator
                next_score[claim_id] = base + damping * propagated
            total = sum(next_score.values()) or 1.0
            score = {key: value / total for key, value in next_score.items()}
        maximum = max(score.values()) or 1.0
        return {key: round(value / maximum, 6) for key, value in score.items()}

    def duplicate_clusters(self, confidence: float = 0.72) -> list[list[str]]:
        parent = {claim_id: claim_id for claim_id in self.claims}

        def find(node: str) -> str:
            while parent[node] != node:
                parent[node] = parent[parent[node]]
                node = parent[node]
            return node

        def union(left: str, right: str) -> None:
            root_left, root_right = find(left), find(right)
            if root_left != root_right:
                parent[root_right] = root_left

        for relation in self.relations:
            if (
                relation.kind == RelationKind.DUPLICATES
                and relation.confidence >= confidence
                and relation.source_claim_id in parent
                and relation.target_claim_id in parent
            ):
                union(relation.source_claim_id, relation.target_claim_id)
        groups: dict[str, list[str]] = defaultdict(list)
        for claim_id in parent:
            groups[find(claim_id)].append(claim_id)
        clusters = [sorted(group) for group in groups.values() if len(group) > 1]
        return sorted(clusters, key=lambda group: (-len(group), group))

    def unresolved_contradictions(
        self,
        assessments: dict[str, ClaimAssessment] | None = None,
        confidence: float = 0.55,
    ) -> list[ClaimRelation]:
        result: list[ClaimRelation] = []
        for relation in self.relations:
            if relation.kind != RelationKind.CONTRADICTS or relation.confidence < confidence:
                continue
            if assessments:
                left = assessments.get(relation.source_claim_id)
                right = assessments.get(relation.target_claim_id)
                if left and left.status == ClaimStatus.FALSIFIED:
                    continue
                if right and right.status == ClaimStatus.FALSIFIED:
                    continue
            result.append(relation)
        return result

    def dependency_cycles(self) -> list[list[str]]:
        adjacency: dict[str, list[str]] = defaultdict(list)
        for relation in self.relations:
            if relation.kind == RelationKind.DEPENDS_ON:
                adjacency[relation.source_claim_id].append(relation.target_claim_id)
        color: dict[str, int] = {claim_id: 0 for claim_id in self.claims}
        stack: list[str] = []
        cycles: list[list[str]] = []
        seen_cycles: set[tuple[str, ...]] = set()

        def visit(node: str) -> None:
            color[node] = 1
            stack.append(node)
            for target in adjacency.get(node, []):
                if target not in color:
                    continue
                if color[target] == 0:
                    visit(target)
                elif color[target] == 1 and target in stack:
                    start = stack.index(target)
                    cycle = stack[start:] + [target]
                    canonical = tuple(sorted(set(cycle)))
                    if canonical not in seen_cycles:
                        cycles.append(cycle)
                        seen_cycles.add(canonical)
            stack.pop()
            color[node] = 2

        for claim_id in self.claims:
            if color[claim_id] == 0:
                visit(claim_id)
        return cycles

    def diagnostics(self, assessments: dict[str, ClaimAssessment] | None = None) -> GraphDiagnostics:
        return GraphDiagnostics(
            duplicate_clusters=self.duplicate_clusters(),
            unresolved_contradictions=self.unresolved_contradictions(assessments),
            dependency_cycles=self.dependency_cycles(),
            centrality=self.centrality(),
            inferred_relation_count=sum(1 for relation in self.relations if relation.inferred),
        )

    @classmethod
    def _is_negated(cls, text: str) -> bool:
        lowered = f' {text.lower()} '
        return any(marker in lowered for marker in cls.NEGATION_MARKERS)

    @classmethod
    def _has_antonym_collision(cls, left: str, right: str) -> bool:
        a, b = left.lower(), right.lower()
        return any((x in a and y in b) or (y in a and x in b) for x, y in cls.ANTONYM_PAIRS)
