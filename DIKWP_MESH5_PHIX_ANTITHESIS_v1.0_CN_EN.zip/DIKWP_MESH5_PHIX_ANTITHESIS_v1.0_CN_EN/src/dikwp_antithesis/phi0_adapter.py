from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from .claim_compiler import ClaimCompiler
from .models import (
    Claim,
    EvidenceItem,
    EvidenceLevel,
    EvidenceResult,
    Portfolio,
    Repository,
)
from .util import read_json, sha256_json, stable_id


class Phi0Adapter:
    """Import DIKWP-MESH5 Φ0 receipts without upgrading self-tests to E5."""

    ADAPTER_VERSION = '1.0'

    def import_directory(
        self,
        directory: str | Path,
        *,
        repo_id: str = 'repo-dikwp-mesh5-phi0',
        repo_url: str = '',
    ) -> Portfolio:
        root = Path(directory)
        summary_path = root / 'summary.json'
        experiments_path = root / 'experiments.json'
        conformance_path = root / 'conformance.json'
        if not summary_path.exists():
            raise FileNotFoundError(f'Φ0 summary not found: {summary_path}')
        summary = read_json(summary_path)
        experiments = read_json(experiments_path) if experiments_path.exists() else {}
        conformance = read_json(conformance_path) if conformance_path.exists() else {}
        aggregate = experiments.get('aggregate', summary.get('experiments', {}))
        producer = str(summary.get('system', 'DIKWP-MESH5 Φ0 reference package'))
        core_text = str(summary.get('core_claim', '')).strip()
        if not core_text:
            raise ValueError('Φ0 summary has no core_claim')

        repo = Repository(
            id=repo_id,
            name=str(summary.get('system', 'DIKWP-MESH5 Φ0')),
            url=repo_url,
            description=str(summary.get('release_handle', 'Asemantic causal-equivalence runtime')),
            mission='Test causal-equivalence alignment without making human semantics a permanent machine-core primitive.',
            tags=['DIKWP', 'MESH5', 'Phi0', 'causal-equivalence', 'asemantic'],
            risk_level=0.64,
            flagship=True,
            metadata={
                'adapter': f'phi0/{self.ADAPTER_VERSION}',
                'source_directory_hash': self._tree_hash(root),
                'seed': summary.get('seed'),
            },
        )
        claim = Claim(
            id=stable_id('CLM', repo_id, core_text),
            repo_id=repo_id,
            text=core_text,
            claim_type='scientific',
            scope='synthetic-reference',
            importance=0.96,
            risk=0.66,
            falsifiability=0.90,
            authority='DIKWP-MESH5 Φ0 release authors and experiment receipts',
            purpose='Determine whether cross-model interventions can align by downstream causal equivalence without fixed human labels.',
            assumptions=[
                'The synthetic AnonymousWorld dynamics are an adequate reference test bed for implementation conformance.',
                'The chosen perturbation family exposes the relevant causal structure.',
                'Passing deterministic seeds does not imply transfer to open-weight or real-world models.',
            ],
            metadata={
                'source': str(summary_path),
                'synthetic_only': True,
                'independent_replication_present': False,
                'overclaim_risk': 0.30,
            },
        )
        claim, contract = ClaimCompiler().compile_contract(claim)
        contract.intervention = (
            'Freeze an intervention family; connect two heterogeneous open-weight models; compare XenoPacket transfer '
            'against text and embedding baselines on held-out perturbations; require an independent team to rerun the protocol.'
        )
        contract.measurement = (
            'Held-out transfer accuracy, cycle error, baseline delta, rollback error, residual magnitude, failure taxonomy, '
            'and cross-team reproducibility across preregistered seeds and model pairs.'
        )
        contract.failure_threshold = (
            'Kill or narrow the broad cross-model claim if transfer fails to exceed both text and embedding baselines on held-out '
            'model pairs, if cycle/rollback invariants fail, or if an independent rerun cannot reproduce the declared margin.'
        )
        contract.counterexample = (
            'A model pair and in-scope perturbation family where textual or embedding transfer succeeds but Φ0 causal-equivalence '
            'mapping fails or produces an untracked residual.'
        )
        contract.estimated_cost = 14.0
        contract.falsification_power = 0.94

        evidence: list[EvidenceItem] = []
        experiment_count = int(aggregate.get('experiments', 0) or 0)
        passed = int(aggregate.get('passed', 0) or 0)
        failed = int(aggregate.get('failed', 0) or 0)
        if experiment_count or experiments_path.exists():
            result = EvidenceResult.SUPPORT if experiment_count > 0 and failed == 0 and passed == experiment_count else EvidenceResult.CHALLENGE
            evidence.append(
                EvidenceItem(
                    id=stable_id('EVD', claim.id, 'phi0-experiment-suite', aggregate),
                    claim_id=claim.id,
                    level=EvidenceLevel.E3_INTERNAL_REPLICATION,
                    result=result,
                    source=str(experiments_path),
                    producer=producer,
                    reproducible=True,
                    checksum=str(aggregate.get('receipts_hash', sha256_json(experiments))),
                    context='Deterministic synthetic reference experiments; not an independent or open-weight replication.',
                    notes=f'{passed}/{experiment_count} experiments passed; {failed} failed.',
                    metrics={
                        'experiments': experiment_count,
                        'passed': passed,
                        'failed': failed,
                    },
                    metadata={'independent': False, 'synthetic': True},
                )
            )
        if conformance:
            conformance_passed = int(conformance.get('passed', 0) or 0)
            conformance_failed = int(conformance.get('failed', 0) or 0)
            evidence.append(
                EvidenceItem(
                    id=stable_id('EVD', claim.id, 'phi0-conformance', conformance),
                    claim_id=claim.id,
                    level=EvidenceLevel.E3_INTERNAL_REPLICATION,
                    result=EvidenceResult.SUPPORT if conformance_failed == 0 and conformance_passed > 0 else EvidenceResult.CHALLENGE,
                    source=str(conformance_path),
                    producer=producer,
                    reproducible=True,
                    checksum=str(conformance.get('report_hash', sha256_json(conformance))),
                    context='Reference-package conformance tests under the same authorship/provenance group.',
                    notes=f'{conformance_passed} conformance checks passed; {conformance_failed} failed.',
                    metrics={'passed': conformance_passed, 'failed': conformance_failed},
                    metadata={'independent': False, 'synthetic': True},
                )
            )
        residual_path = root / 'residual_reserve.json'
        if residual_path.exists():
            residual = read_json(residual_path)
            evidence.append(
                EvidenceItem(
                    id=stable_id('EVD', claim.id, 'phi0-residual', residual),
                    claim_id=claim.id,
                    level=EvidenceLevel.E2_EXECUTABLE,
                    result=EvidenceResult.INCONCLUSIVE,
                    source=str(residual_path),
                    producer=producer,
                    reproducible=True,
                    checksum=sha256_json(residual),
                    context='Unmatched structure is retained as a residual rather than silently projected away.',
                    notes='Residual is preserved as a next-probe obligation, not counted as support.',
                    metrics={
                        key: value
                        for key, value in residual.items()
                        if isinstance(value, (int, float, str, bool))
                    },
                    metadata={'independent': False, 'residual_first_class': True},
                )
            )
        return Portfolio(
            repositories=[repo],
            claims=[claim],
            evidence=evidence,
            contracts=[contract],
            metadata={
                'adapter': f'Phi0Adapter/{self.ADAPTER_VERSION}',
                'critical_caveat': 'All imported passing results remain E3 internal evidence until independent replication exists.',
            },
        )

    @staticmethod
    def _tree_hash(root: Path) -> str:
        digest = hashlib.sha256()
        for path in sorted(root.rglob('*.json')):
            digest.update(str(path.relative_to(root)).encode('utf-8'))
            digest.update(path.read_bytes())
        return digest.hexdigest()
