from __future__ import annotations

from datetime import datetime, timezone

from .claim_compiler import ClaimCompiler
from .constitution import ReleaseConstitution
from .evidence import EvidenceEngine
from .graph import ClaimGraph
from .ledger import HashLedger
from .models import (
    Claim,
    ClaimRelation,
    DecisionState,
    EvidenceItem,
    EvidenceLevel,
    EvidenceResult,
    RelationKind,
    Repository,
)
from .planner import ExperimentPlanner
from .util import sha256_json, stable_id


def run_conformance() -> dict:
    tests: list[dict] = []

    def check(name: str, function) -> None:
        try:
            function()
            tests.append({'name': name, 'passed': True, 'error': ''})
        except Exception as exc:  # conformance report must retain failures
            tests.append({'name': name, 'passed': False, 'error': f'{type(exc).__name__}: {exc}'})

    check('canonical_hash_stability', _test_hash_stability)
    check('ledger_chain_verifies', _test_ledger_verifies)
    check('ledger_tamper_detected', _test_ledger_tamper)
    check('traceability_is_not_support', _test_e1_not_supported)
    check('same_team_internal_evidence_is_discounted', _test_independence_discount)
    check('missing_rollback_forces_hold', _test_missing_rollback)
    check('high_risk_without_e2_forces_hold', _test_high_risk_hold)
    check('internal_e3_cannot_promote', _test_internal_e3_not_promote)
    check('falsified_core_claim_retires', _test_falsified_retires)
    check('duplicate_cluster_is_explicit', _test_duplicate_cluster)
    check('planner_respects_budget', _test_planner_budget)
    check('compiled_claim_receives_kill_test', _test_contract_compilation)
    passed = sum(1 for item in tests if item['passed'])
    failed = len(tests) - passed
    report = {
        'system': 'DIKWP-MESH5 ΦX / ANTITHESIS',
        'suite': 'constitutional-conformance-v1',
        'passed': passed,
        'failed': failed,
        'status': 'PASS' if failed == 0 else 'FAIL',
        'tests': tests,
    }
    report['report_hash'] = sha256_json(report)
    return report


def _claim(**overrides) -> Claim:
    values = {
        'id': 'c1',
        'repo_id': 'r1',
        'text': 'The runtime detects ledger tampering under the declared test scope.',
        'claim_type': 'infrastructure',
        'scope': 'test',
        'importance': 0.9,
        'risk': 0.5,
        'falsifiability': 0.8,
        'kill_test': 'Fail when tampering is not detected.',
        'rollback': 'Restore the sealed ledger.',
        'authority': 'test authority',
        'purpose': 'test purpose',
    }
    values.update(overrides)
    return Claim(**values)


def _repo(**overrides) -> Repository:
    values = {'id': 'r1', 'name': 'test-repo', 'risk_level': 0.5}
    values.update(overrides)
    return Repository(**values)


def _evidence(level=3, result='support', producer='team-a', evidence_id='e1') -> EvidenceItem:
    return EvidenceItem(
        id=evidence_id,
        claim_id='c1',
        level=level,
        result=result,
        source='test',
        producer=producer,
        reproducible=True,
    )


def _decision(repo: Repository, claim: Claim, evidence: list[EvidenceItem]):
    engine = EvidenceEngine()
    assessment = engine.assess(claim, evidence)
    graph = ClaimGraph([claim])
    return ReleaseConstitution().evaluate_repository(
        repo,
        [claim],
        {claim.id: assessment},
        graph,
        as_of=datetime(2026, 7, 22, tzinfo=timezone.utc),
    )


def _test_hash_stability() -> None:
    assert sha256_json({'b': 2, 'a': 1}) == sha256_json({'a': 1, 'b': 2})


def _test_ledger_verifies() -> None:
    ledger = HashLedger()
    ledger.append('A', {'x': 1}, timestamp='2026-01-01T00:00:00Z')
    ledger.append('B', {'x': 2}, timestamp='2026-01-01T00:00:01Z')
    assert ledger.verify()['status'] == 'PASS'


def _test_ledger_tamper() -> None:
    ledger = HashLedger()
    ledger.append('A', {'x': 1}, timestamp='2026-01-01T00:00:00Z')
    ledger.records[0]['payload']['x'] = 999
    assert ledger.verify()['status'] == 'FAIL'


def _test_e1_not_supported() -> None:
    assessment = EvidenceEngine().assess(_claim(), [_evidence(level=1)])
    assert assessment.status.value == 'UNTESTED'


def _test_independence_discount() -> None:
    items = [_evidence(level=3, evidence_id=f'e{i}') for i in range(5)]
    assessment = EvidenceEngine().assess(_claim(), items)
    assert assessment.evidence_level == EvidenceLevel.E3_INTERNAL_REPLICATION
    assert assessment.independence_score < 0.5


def _test_missing_rollback() -> None:
    decision = _decision(_repo(), _claim(rollback=''), [_evidence(level=3), _evidence(level=2, evidence_id='e2')])
    assert decision.state == DecisionState.HOLD


def _test_high_risk_hold() -> None:
    decision = _decision(_repo(risk_level=0.9), _claim(risk=0.9), [_evidence(level=1)])
    assert decision.state == DecisionState.HOLD


def _test_internal_e3_not_promote() -> None:
    decision = _decision(_repo(), _claim(), [_evidence(level=3), _evidence(level=2, evidence_id='e2')])
    assert decision.state == DecisionState.PILOT


def _test_falsified_retires() -> None:
    decision = _decision(_repo(), _claim(), [_evidence(level=3, result='falsify')])
    assert decision.state == DecisionState.RETIRE


def _test_duplicate_cluster() -> None:
    left = _claim(id='c1', text='The runtime detects ledger tampering under the declared test scope.')
    right = _claim(id='c2', repo_id='r2', text='The runtime detects ledger tampering within the declared test scope.')
    graph = ClaimGraph([left, right])
    graph.infer_relations(duplicate_threshold=0.5)
    assert graph.duplicate_clusters(confidence=0.5)


def _test_planner_budget() -> None:
    claims = [_claim(id='c1'), _claim(id='c2', repo_id='r2', text='The runtime detects protocol corruption.')]
    compiler = ClaimCompiler()
    compiled, contracts = compiler.compile_many(claims)
    evidence = [_evidence(level=1)]
    engine = EvidenceEngine()
    assessments = engine.assess_all(compiled, evidence)
    graph = ClaimGraph(compiled)
    plans = ExperimentPlanner().plan(compiled, contracts, assessments, graph)
    selected = ExperimentPlanner().minimum_decisive_set(plans, graph, budget=contracts[0].estimated_cost)
    assert sum(item.estimated_cost for item in selected) <= contracts[0].estimated_cost + 1e-9


def _test_contract_compilation() -> None:
    claim, contract = ClaimCompiler().compile_contract(_claim(kill_test='', rollback=''))
    assert claim.kill_test and claim.rollback and contract.failure_threshold
