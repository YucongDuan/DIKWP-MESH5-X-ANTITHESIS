from __future__ import annotations

from collections import Counter, defaultdict
from typing import Iterable

from .models import (
    Claim,
    ClaimAssessment,
    ClaimStatus,
    EvidenceItem,
    EvidenceLevel,
    EvidenceResult,
)
from .util import clamp, logit, sigmoid


class EvidenceEngine:
    """Claim-level evidence assessment with explicit independence discounting."""

    BASE_STRENGTH = {
        EvidenceLevel.E0_ASSERTION: 0.0,
        EvidenceLevel.E1_TRACEABLE: 0.15,
        EvidenceLevel.E2_EXECUTABLE: 0.35,
        EvidenceLevel.E3_INTERNAL_REPLICATION: 0.75,
        EvidenceLevel.E4_ADVERSARIAL: 1.05,
        EvidenceLevel.E5_INDEPENDENT_REPLICATION: 1.35,
        EvidenceLevel.E6_CROSS_CONTEXT: 1.65,
        EvidenceLevel.E7_SUSTAINED_AUDIT: 1.90,
    }

    def __init__(self, prior: float = 0.35) -> None:
        self.prior = clamp(prior, 0.05, 0.95)

    def assess(self, claim: Claim, evidence: Iterable[EvidenceItem]) -> ClaimAssessment:
        items = [item for item in evidence if item.claim_id == claim.id]
        if not items:
            return ClaimAssessment(
                claim_id=claim.id,
                evidence_level=EvidenceLevel.E0_ASSERTION,
                credence=self.prior,
                independence_score=0.0,
                status=ClaimStatus.UNTESTED,
                support_weight=0.0,
                challenge_weight=0.0,
                evidence_count=0,
                rationale=['No evidence receipt is attached to this claim.'],
            )

        producer_seen: Counter[str] = Counter()
        log_odds = logit(self.prior)
        support_weight = 0.0
        challenge_weight = 0.0
        strongest_falsifier = 0.0
        max_level = EvidenceLevel.E0_ASSERTION
        rationale: list[str] = []

        for item in sorted(items, key=lambda x: (-int(x.level), x.timestamp, x.id)):
            max_level = max(max_level, item.level)
            producer_key = (item.producer or item.source or 'unknown').strip().lower()
            repetition_index = producer_seen[producer_key]
            producer_seen[producer_key] += 1
            repetition_discount = 1.0 if repetition_index == 0 else max(0.18, 0.38 ** repetition_index)
            independent_bonus = 1.0
            if item.level >= EvidenceLevel.E5_INDEPENDENT_REPLICATION or bool(item.metadata.get('independent')):
                independent_bonus = 1.12
            reproducibility_bonus = 1.08 if item.reproducible else 1.0
            strength = self.BASE_STRENGTH[item.level] * repetition_discount * independent_bonus * reproducibility_bonus

            if item.result == EvidenceResult.SUPPORT:
                log_odds += strength
                support_weight += strength
            elif item.result == EvidenceResult.CHALLENGE:
                log_odds -= strength
                challenge_weight += strength
            elif item.result == EvidenceResult.FALSIFY:
                falsifier = strength * 1.35
                log_odds -= falsifier
                challenge_weight += falsifier
                strongest_falsifier = max(strongest_falsifier, falsifier)
            else:
                rationale.append(f'{item.id}: inconclusive evidence retained without directional update.')

        credence = clamp(sigmoid(log_odds))
        independence = self.independence_score(items)

        if strongest_falsifier >= self.BASE_STRENGTH[EvidenceLevel.E3_INTERNAL_REPLICATION] * 0.8:
            status = ClaimStatus.FALSIFIED
            rationale.append('At least one executable/internal-or-stronger receipt crosses the falsification threshold.')
        elif support_weight >= 0.45 and challenge_weight >= 0.40:
            status = ClaimStatus.CONTESTED
            rationale.append('Material support and challenge coexist; the claim remains contested.')
        elif credence >= 0.67 and max_level >= EvidenceLevel.E3_INTERNAL_REPLICATION:
            status = ClaimStatus.SUPPORTED
            rationale.append('Credence and evidence depth meet the support threshold.')
        else:
            status = ClaimStatus.UNTESTED
            rationale.append('Evidence remains below the support threshold or is limited to traceability/executability.')

        if max_level < EvidenceLevel.E5_INDEPENDENT_REPLICATION:
            rationale.append('No independent replication receipt is present; self-produced success is discounted.')
        if independence < 0.5:
            rationale.append('Evidence-source independence is below 0.50.')

        return ClaimAssessment(
            claim_id=claim.id,
            evidence_level=max_level,
            credence=round(credence, 6),
            independence_score=round(independence, 6),
            status=status,
            support_weight=round(support_weight, 6),
            challenge_weight=round(challenge_weight, 6),
            evidence_count=len(items),
            rationale=rationale,
        )

    def assess_all(self, claims: Iterable[Claim], evidence: Iterable[EvidenceItem]) -> dict[str, ClaimAssessment]:
        grouped: dict[str, list[EvidenceItem]] = defaultdict(list)
        for item in evidence:
            grouped[item.claim_id].append(item)
        return {claim.id: self.assess(claim, grouped.get(claim.id, [])) for claim in claims}

    def independence_score(self, evidence: Iterable[EvidenceItem]) -> float:
        items = [item for item in evidence if item.level > EvidenceLevel.E0_ASSERTION]
        if not items:
            return 0.0
        groups = {(item.producer or item.source or 'unknown').strip().lower() for item in items}
        if len(items) == 1:
            diversity = 0.0
        else:
            diversity = (len(groups) - 1) / (len(items) - 1)
        total_weight = sum(max(0.01, self.BASE_STRENGTH[item.level]) for item in items)
        independent_weight = sum(
            max(0.01, self.BASE_STRENGTH[item.level])
            for item in items
            if item.level >= EvidenceLevel.E5_INDEPENDENT_REPLICATION or bool(item.metadata.get('independent'))
        )
        independent_fraction = independent_weight / total_weight if total_weight else 0.0
        return clamp(0.10 + 0.45 * diversity + 0.45 * independent_fraction)
