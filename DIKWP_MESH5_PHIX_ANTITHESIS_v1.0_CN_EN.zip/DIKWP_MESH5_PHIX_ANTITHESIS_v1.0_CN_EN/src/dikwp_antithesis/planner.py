from __future__ import annotations

from collections import defaultdict
from dataclasses import replace
from typing import Iterable

from .graph import ClaimGraph
from .models import (
    Claim,
    ClaimAssessment,
    ClaimStatus,
    EvidenceLevel,
    ExperimentPlan,
    FalsificationContract,
)
from .util import binary_entropy, clamp, stable_id


class ExperimentPlanner:
    """Rank minimum decisive experiments rather than maximum activity."""

    def plan(
        self,
        claims: Iterable[Claim],
        contracts: Iterable[FalsificationContract],
        assessments: dict[str, ClaimAssessment],
        graph: ClaimGraph,
    ) -> list[ExperimentPlan]:
        claim_map = {claim.id: claim for claim in claims}
        contract_map = {contract.claim_id: contract for contract in contracts}
        centrality = graph.centrality()
        contradiction_claims = {
            claim_id
            for relation in graph.unresolved_contradictions(assessments)
            for claim_id in (relation.source_claim_id, relation.target_claim_id)
        }
        costs = [contract.estimated_cost for contract in contract_map.values()]
        max_cost = max(costs) if costs else 1.0
        plans: list[ExperimentPlan] = []

        for claim_id, claim in claim_map.items():
            contract = contract_map.get(claim_id)
            if contract is None:
                continue
            assessment = assessments[claim_id]
            uncertainty = binary_entropy(assessment.credence)
            central = centrality.get(claim_id, 0.0)
            independence_gap = 1.0 - assessment.independence_score
            cost_norm = contract.estimated_cost / max_cost
            contradiction_bonus = 1.0 if claim_id in contradiction_claims else 0.0
            falsified_bonus = 1.0 if assessment.status == ClaimStatus.FALSIFIED else 0.0

            raw = (
                0.23 * uncertainty
                + 0.17 * claim.importance
                + 0.13 * central
                + 0.14 * contract.falsification_power
                + 0.10 * independence_gap
                + 0.07 * contract.reversibility
                + 0.07 * claim.risk
                + 0.08 * contradiction_bonus
                + 0.05 * falsified_bonus
                - 0.10 * cost_norm
            )
            score = round(100.0 * clamp(raw), 3)
            information_gain = round(
                clamp(uncertainty * contract.falsification_power * (0.65 + 0.35 * independence_gap)), 6
            )
            reasons = self._reasons(
                claim=claim,
                assessment=assessment,
                centrality=central,
                contradiction=bool(contradiction_bonus),
                contract=contract,
            )
            plans.append(
                ExperimentPlan(
                    rank=0,
                    contract_id=contract.id,
                    claim_id=claim.id,
                    repo_id=claim.repo_id,
                    score=score,
                    expected_information_gain=information_gain,
                    priority_reasons=reasons,
                    estimated_cost=contract.estimated_cost,
                    stop_condition=contract.stop_condition,
                    decision_unlocked=self._decision_unlocked(assessment),
                    target_claim_ids=[claim.id],
                    experiment_type='claim-kill-test',
                    intervention=contract.intervention,
                    measurement=contract.measurement,
                    failure_threshold=contract.failure_threshold,
                    rollback=contract.rollback,
                )
            )

        plans.extend(self._contradiction_plans(claim_map, assessments, graph, centrality))
        plans.sort(key=lambda plan: (-plan.score, plan.estimated_cost, plan.claim_id))
        for rank, plan in enumerate(plans, 1):
            plan.rank = rank
        return plans

    def minimum_decisive_set(
        self,
        plans: Iterable[ExperimentPlan],
        graph: ClaimGraph,
        *,
        budget: float,
        max_experiments: int = 12,
    ) -> list[ExperimentPlan]:
        """Greedy portfolio cover with duplicate-cluster suppression.

        It prioritizes score per cost, unresolved contradiction endpoints, and
        repository diversity while avoiding spending twice on near-duplicate claims.
        """
        candidates = list(plans)
        clusters = graph.duplicate_clusters()
        cluster_of: dict[str, int] = {}
        for index, cluster in enumerate(clusters):
            for claim_id in cluster:
                cluster_of[claim_id] = index
        contradiction_claims = {
            claim_id
            for relation in graph.unresolved_contradictions()
            for claim_id in (relation.source_claim_id, relation.target_claim_id)
        }
        selected: list[ExperimentPlan] = []
        used_budget = 0.0
        covered_clusters: set[int] = set()
        covered_claims: set[str] = set()
        covered_repos: defaultdict[str, int] = defaultdict(int)
        remaining = candidates[:]

        while remaining and len(selected) < max_experiments:
            best: ExperimentPlan | None = None
            best_utility = -1.0
            for plan in remaining:
                if used_budget + plan.estimated_cost > budget:
                    continue
                duplicate_penalty = 0.42 if cluster_of.get(plan.claim_id) in covered_clusters else 1.0
                diversity_bonus = 1.18 if covered_repos[plan.repo_id] == 0 else 0.92
                targets = set(plan.target_claim_ids or [plan.claim_id])
                contradiction_bonus = 1.28 if targets & contradiction_claims else 1.0
                bridge_bonus = 2.00 if plan.experiment_type == 'contradiction-bridge' else 1.0
                overlap_penalty = 0.45 if targets and targets <= covered_claims else 1.0
                utility = (
                    plan.score
                    * duplicate_penalty
                    * diversity_bonus
                    * contradiction_bonus
                    * bridge_bonus
                    * overlap_penalty
                    / max(0.5, plan.estimated_cost)
                )
                if utility > best_utility:
                    best_utility = utility
                    best = plan
            if best is None:
                break
            selected.append(best)
            used_budget += best.estimated_cost
            covered_repos[best.repo_id] += 1
            targets = set(best.target_claim_ids or [best.claim_id])
            covered_claims.update(targets)
            for target in targets:
                if target in cluster_of:
                    covered_clusters.add(cluster_of[target])
            remaining.remove(best)
        return [replace(plan, rank=index) for index, plan in enumerate(selected, 1)]


    def _contradiction_plans(
        self,
        claim_map: dict[str, Claim],
        assessments: dict[str, ClaimAssessment],
        graph: ClaimGraph,
        centrality: dict[str, float],
    ) -> list[ExperimentPlan]:
        plans: list[ExperimentPlan] = []
        for relation in graph.unresolved_contradictions(assessments):
            left = claim_map.get(relation.source_claim_id)
            right = claim_map.get(relation.target_claim_id)
            if not left or not right:
                continue
            left_assessment = assessments[left.id]
            right_assessment = assessments[right.id]
            uncertainty = (binary_entropy(left_assessment.credence) + binary_entropy(right_assessment.credence)) / 2.0
            importance = max(left.importance, right.importance)
            network = max(centrality.get(left.id, 0.0), centrality.get(right.id, 0.0))
            independence_gap = 1.0 - min(left_assessment.independence_score, right_assessment.independence_score)
            risk = max(left.risk, right.risk)
            cost = round(5.0 + 4.0 * risk, 2)
            raw = (
                0.24 * uncertainty
                + 0.18 * importance
                + 0.15 * network
                + 0.16 * relation.confidence
                + 0.11 * independence_gap
                + 0.08 * risk
                + 0.10
                - 0.05 * min(1.0, cost / 15.0)
            )
            score = round(100.0 * clamp(raw), 3)
            plans.append(
                ExperimentPlan(
                    rank=0,
                    contract_id=stable_id('BRIDGE', left.id, right.id, relation.rationale),
                    claim_id=left.id,
                    repo_id=left.repo_id,
                    score=score,
                    expected_information_gain=round(clamp(uncertainty * relation.confidence * (0.75 + 0.25 * independence_gap)), 6),
                    priority_reasons=[
                        'unresolved cross-repository contradiction',
                        f'contradiction confidence ({relation.confidence:.2f})',
                        f'joint importance ({importance:.2f})',
                        f'evidence independence gap ({independence_gap:.2f})',
                    ],
                    estimated_cost=cost,
                    stop_condition=(
                        'Stop on scope mismatch, evaluator leakage, irreversible action, or when neither side exposes a '
                        'predeclared observation that could distinguish the competing interface contracts.'
                    ),
                    decision_unlocked=(
                        f'Resolve joint REVIEW for {left.repo_id} and {right.repo_id}; retain both only if a scoped layer '
                        'distinction is experimentally observable and round-trip safe.'
                    ),
                    target_claim_ids=[left.id, right.id],
                    experiment_type='contradiction-bridge',
                    intervention=(
                        'Freeze one perturbation family and two heterogeneous open-weight models. Compare three arms: '
                        '(A) Φ0 causal-equivalence transfer, (B) Runtime Commons semantic-contract transfer, and '
                        '(C) a layered Φ0-core → lossy DIKWP audit shadow → Runtime contract. Preregister the interface '
                        'and prohibit post-result redefinition.'
                    ),
                    measurement=(
                        'Held-out transfer accuracy, cycle error, projection loss, semantic leakage into the Φ0 core, '
                        'residual retention, 25-transform conformance, rollback error, and cross-team reproducibility.'
                    ),
                    failure_threshold=(
                        'Reject the unified layered architecture if the semantic witness changes Φ0 equivalence classes, '
                        'if Φ0 cannot expose a stable auditable shadow, if residuals disappear, or if either standalone '
                        'arm outperforms the layered arm beyond the preregistered tolerance.'
                    ),
                    rollback=(
                        'Keep Φ0 and Runtime Commons as separate scoped systems, record the failed interface contract, '
                        'and prohibit cross-layer promotion until a newly versioned bridge passes.'
                    ),
                )
            )
        return plans

    @staticmethod
    def _decision_unlocked(assessment: ClaimAssessment) -> str:
        if assessment.status == ClaimStatus.FALSIFIED:
            return 'Confirm RETIRE or document a narrower replacement claim.'
        if assessment.evidence_level >= EvidenceLevel.E5_INDEPENDENT_REPLICATION:
            return 'Resolve PROMOTE versus cross-context E6 validation.'
        if assessment.evidence_level >= EvidenceLevel.E3_INTERNAL_REPLICATION:
            return 'Move PILOT toward PROMOTE only through independent replication.'
        if assessment.evidence_level >= EvidenceLevel.E2_EXECUTABLE:
            return 'Move REVIEW/HOLD toward PILOT through repeated adversarial execution.'
        return 'Convert a traceable assertion into an executable E2/E3 result.'

    @staticmethod
    def _reasons(
        *,
        claim: Claim,
        assessment: ClaimAssessment,
        centrality: float,
        contradiction: bool,
        contract: FalsificationContract,
    ) -> list[str]:
        reasons: list[tuple[float, str]] = []
        reasons.append((binary_entropy(assessment.credence), f'high uncertainty (credence={assessment.credence:.3f})'))
        reasons.append((claim.importance, f'high claim importance ({claim.importance:.2f})'))
        reasons.append((centrality, f'portfolio centrality ({centrality:.2f})'))
        reasons.append((1.0 - assessment.independence_score, f'independence gap ({1.0 - assessment.independence_score:.2f})'))
        reasons.append((contract.falsification_power, f'falsification power ({contract.falsification_power:.2f})'))
        if contradiction:
            reasons.append((1.15, 'unresolved contradiction touches this claim'))
        if claim.risk >= 0.7:
            reasons.append((claim.risk, f'high consequence if wrong ({claim.risk:.2f})'))
        return [text for _, text in sorted(reasons, key=lambda item: -item[0])[:4]]
