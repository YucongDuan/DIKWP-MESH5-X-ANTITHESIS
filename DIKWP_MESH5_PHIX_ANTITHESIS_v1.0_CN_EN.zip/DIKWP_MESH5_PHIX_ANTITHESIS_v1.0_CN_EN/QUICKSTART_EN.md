# Quick start (English)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .

dikwp-antithesis conformance --out outputs/conformance.json

dikwp-antithesis demo \
  --out outputs/demo \
  --phi0 /path/to/phi0/outputs/research_run \
  --budget 60
```

Open `outputs/demo/dashboard.html` in a browser.

Verify the evidence and decision ledger:

```bash
dikwp-antithesis verify-ledger --input outputs/demo/ledger.jsonl
```

Compile a custom portfolio:

```bash
dikwp-antithesis compile \
  --input examples/portfolio_minimal.json \
  --out outputs/custom \
  --policy config/default_constitution.json
```

A GitHub README creates only an E1 traceable assertion. Public code, stars, commits, and author-side tests do not create independent replication.
